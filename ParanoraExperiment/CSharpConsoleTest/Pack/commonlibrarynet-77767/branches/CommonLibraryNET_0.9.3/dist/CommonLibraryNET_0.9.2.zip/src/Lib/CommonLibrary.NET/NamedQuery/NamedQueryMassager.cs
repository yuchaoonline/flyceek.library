using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using CommonLibrary.DomainModel;


namespace CommonLibrary
{
    /// <summary>
    /// Data massager for an entity.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public partial class NamedQueryMassager : EntityMassager
    {        
    }
}
