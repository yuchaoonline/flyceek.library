﻿using System;
using System.Collections.Generic;
using System.Text;
using CommonLibrary;

using NUnit.Framework;
using CommonLibrary.Models;


namespace CommonLibrary.Tests
{

    [TestFixture]
    public class MapperTests
    {
        [Test]
        public void CanMapObject()
        {
            /*
            StatusUpdate update = new StatusUpdate();
            Mapper mapper = new Mapper();
            Model model = new Model();
            OrmSqlBuilder sqlBuilder = new OrmSqlBuilder("sqlserver", model);
            string sqlInsert = sqlBuilder.GetInsert();
            */
            //Model
        }
    }
}
