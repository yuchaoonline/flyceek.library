﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using NUnit.Framework;


using ComLib.Membership;
using ComLib.Entities;


namespace CommonLibrary.Tests
{
    [TestFixture]
    public class AccountTests
    {
        [SetUp]
        public void Setup()
        {
        }


        [Test]
        public void IsDuplicateEmail()
        {
            
        }
    }
}
