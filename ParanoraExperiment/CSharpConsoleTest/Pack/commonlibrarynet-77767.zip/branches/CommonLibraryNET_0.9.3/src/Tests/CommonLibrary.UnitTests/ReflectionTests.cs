﻿using System;
using System.Collections.Generic;
using System.Text;


using NUnit.Framework;
using ComLib.Models;


namespace CommonLibrary.Tests
{

    [TestFixture]
    public class MapperTests
    {
        [Test]
        public void CanMapObject()
        {
            /*
            StatusUpdate update = new StatusUpdate();
            Mapper mapper = new Mapper();
            Model model = new Model();
            OrmSqlBuilder sqlBuilder = new OrmSqlBuilder("sqlserver", model);
            string sqlInsert = sqlBuilder.GetInsert();
            */
            //Model
        }
    }
}
