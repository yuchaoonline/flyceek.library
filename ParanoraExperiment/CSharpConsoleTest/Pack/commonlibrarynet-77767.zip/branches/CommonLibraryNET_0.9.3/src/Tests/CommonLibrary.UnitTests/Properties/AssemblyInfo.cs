using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("CommonLibrary.Tests")]
[assembly: AssemblyDescription("Domain Model layer")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Workshops")]
[assembly: AssemblyProduct("CommonLibrary.Tests")]
[assembly: AssemblyCopyright("Copyright © Workshops 2007")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("80f5bcef-2716-47bd-bc32-f3d4f542ac01")]
