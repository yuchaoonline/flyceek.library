using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Core
{
    public interface IDataPage
    {
        int PageIndex
        {
            get;
            set;
        }
        int PageSize
        {
            get;
            set;
        }
        int RecordCount
        {
            get;
            set;
        }
        int PageCount
        {
            get;
        }
        string OrderField
        {
            get;
            set;
        }

    }
    public interface IDataPageProperty
    {
        IDataPage DataPage
        {
            get;
            set;
        }
    }
    [Serializable]
    public class DataPage : IDataPage
    {
        #region IDataPage ��Ա
        private int mPageIndex = 0;
        public int PageIndex
        {
            get
            {
                return mPageIndex;
            }
            set
            {
                mPageIndex = value;
            }
        }
        private int mPageSize = 10;
        public int PageSize
        {
            get
            {
                return mPageSize;
            }
            set
            {
                mPageSize = value;
            }
        }
        private int mRecordCount = 0;
        public int RecordCount
        {
            get
            {
                return mRecordCount;
            }
            set
            {
                mRecordCount = value;
            }
        }
        public int PageCount
        {
            get
            {
                int mCount;
                if (PageSize == 0)
                    PageSize = 10;
                if (RecordCount % PageSize > 0)
                    mCount = RecordCount / PageSize + 1;
                else
                    mCount = RecordCount / PageSize;
                if (mCount == 0)
                    mCount = mCount + 1;
                return mCount;
            }
        }
        private string mOrderField;
        public string OrderField
        {
            get
            {
                return mOrderField;
            }
            set
            {
                mOrderField = value;
            }
        }

        #endregion
    }

}
