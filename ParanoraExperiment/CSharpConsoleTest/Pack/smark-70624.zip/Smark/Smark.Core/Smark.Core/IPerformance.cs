using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Core
{
    public interface IPerformance
    {
        long Execute(int count);
    }
    public abstract class Performance : IPerformance
    {
        #region IPerformance ��Ա

        public long Execute(int count)
        {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Reset();
            sw.Start();
            for (int i = 0; i < count; i++)
            {
                OnExecute();
            }
            sw.Stop();
            return sw.ElapsedMilliseconds;
        }
        
        protected abstract void OnExecute();

        #endregion
    }
    public class PerformanceTest
    {
        private System.IO.TextWriter mWriter;
        public PerformanceTest(System.IO.TextWriter writer)
        {
            mWriter = writer;
        }
        private IPerformance[] mPerformance;
        public void AddPerformance(params IPerformance[] performances)
        {
            mPerformance = performances;
        }
        private string[] Names;
        public void AddTestName(params string[] testname)
        {
            Names = testname;
        }
        public void Execute(int count)
        {
            Execute(count, true); 
        }
        public void Execute(int count, bool outTest)
        {
            int[] result = new int[mPerformance.Length];
            for (int i = 0; i < mPerformance.Length; i++)
            {
                result[i] = System.Convert.ToInt32(mPerformance[i].Execute(count));
            }
            OutTitle();
            if (outTest)
            {
                mWriter.Write("Start(" + count + "):");
                for (int i = 0; i < mPerformance.Length; i++)
                {

                    mWriter.Write("\t"+result[i].ToString("000000") );
                }
                mWriter.WriteLine();
                
            }

            mWriter.Flush();
        }
        private bool mIsOut = false;
        private void OutTitle()
        {
            if (!mIsOut)
            {
                mWriter.Write("\t");
                for (int i = 0; i < mPerformance.Length; i++)
                {
                    mWriter.Write("\t"+Names[i] );
                }
                mWriter.WriteLine();
                mIsOut = true;
            }
        }
    }
}
