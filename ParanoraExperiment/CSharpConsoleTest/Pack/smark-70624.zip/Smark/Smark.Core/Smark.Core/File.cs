﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Remoting.Messaging;
namespace Smark.Core
{
    public class File
    {
        private string mName;
		public string Name
        {
            get
			{
				return mName;
			}
            set
			{
				mName = value;
			}
        }
		private long mSize;
        public long Size
        {
            get
			{
				return mSize;
			}
            set
			{
				mSize = value;
			}
        }
		private string mFileType;
        public string FileType
        {
            get
			{
				return mFileType;
			}
            set
			{
				mFileType= value;
			}
        }
		private byte[] mData;
        public byte[] Data
        {
            get
			{
				return mData;
			}
            set
			{
				mData = value;
			}
        }

       
        public void Save(string filename)
        {
            using (FileStream fs = System.IO.File.Open(filename, FileMode.Create, FileAccess.Write))
            {

                fs.Write(Data, 0, Data.Length);
                fs.Flush();
                fs.Close();
            }

        }
        public void AsynSave(string filename)
        {
            Action<string> action = Save;
            action.BeginInvoke(filename, iar =>
            {
                Action<string> end = (Action<string>)((AsyncResult)iar).AsyncDelegate;
                end.EndInvoke(iar);
            }, null);
        }
    }
}
