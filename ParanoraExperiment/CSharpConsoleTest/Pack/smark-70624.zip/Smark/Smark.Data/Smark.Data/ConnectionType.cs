﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Data
{
    /// <summary>
    /// 数据库连接项
    /// </summary>
    public enum ConnectionType
    {
        Context1,
        Context2,
        Context3,
        Context4,
        Context5,
        Context6,
        Context7,
        Context8,
        Context9,
        Context10,
        Context11,
        Context12,
        Context13,
        Context14,
        Context15,
        Context16,
        Context17,
        Context18,
        Context19,
        Context20,
        Context21,
        Context22,
        Context23,
        Context24,
        Context25,
        Context26,
        Context27,
        Context28,
        Context29,
        Context30


    }
}
