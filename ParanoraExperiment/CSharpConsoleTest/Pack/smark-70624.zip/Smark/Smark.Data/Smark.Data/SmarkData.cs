﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data.Odbc;
using System.Text.RegularExpressions;
using System.Reflection;
using System.Collections;
using Smark.Core;
// 开源协议:Apache License, Version 2.0
// Copyright © FanJianHan 2008
// mail:henryfan@msn.com
namespace Smark.Data
{

  

   

 
    /// <summary>
   
    /// MSSQL数据库
    /// </summary>
    public class MSSQL : IDriver {
        #region IDriver 成员

        public IDbConnection Connection {
            get { return new SqlConnection(); }
        }

        public IDbDataAdapter DataAdapter(IDbCommand cmd) {
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = (SqlCommand)cmd;
            return da;
        }

        public IDbCommand Command {
            get {
                return new SqlCommand();
            }
        }

        public string ReplaceSql(String sql) {
            return sql.Replace("@", "@");
        }

        public IDataParameter CreateParameter(string name, object value, ParameterDirection direction) {
            SqlParameter sp = new SqlParameter("@" + name, value);
            if (value == null)
                sp.Value = DBNull.Value;
            sp.Direction = direction;
            return sp;
        }

        #endregion


        public IDataParameter CreateProcParameter(string name, object value, ParameterDirection direction)
        {
            SqlParameter sp = new SqlParameter("@" + name, value);
            if (value == null)
                sp.Value = DBNull.Value;
            sp.Direction = direction;
            return sp;
        }
    }
    /// <summary>
   
    /// ACCESS数据库
    /// </summary>
    public class MSAccess : IDriver {
        #region IDriver 成员

        public IDbConnection Connection {
            get { return new OleDbConnection(); }
        }

        public IDbDataAdapter DataAdapter(IDbCommand cmd) {
            OleDbDataAdapter da = new OleDbDataAdapter();
            da.SelectCommand = (OleDbCommand)cmd;
            return da;
        }

        public IDbCommand Command {
            get {
                return new OleDbCommand();
            }
        }

        public string ReplaceSql(String sql) {
            return sql.Replace("@", "@");
        }

        public IDataParameter CreateParameter(string name, object value, ParameterDirection direction) {
            OleDbParameter sp = new OleDbParameter("@" + name, value);
            sp.Direction = direction;
            if (value == null)
                sp.Value = DBNull.Value;
            else if (value.GetType() == typeof(DateTime))
            {
                sp.Value = value.ToString();
            }
            else
            {
                sp.Value = value;
            }
            return sp;
        }

        #endregion


        public IDataParameter CreateProcParameter(string name, object value, ParameterDirection direction)
        {
            OleDbParameter sp = new OleDbParameter("@" + name, value);
            sp.Direction = direction;
            if (value == null)
                sp.Value = DBNull.Value;
            else if (value.GetType() == typeof(DateTime))
            {
                sp.Value = value.ToString();
            }
            else
            {
                sp.Value = value;
            }
            return sp;
        }
    }
    /// <summary>
  
    /// ODBC数据库
    /// </summary>
    public class ODBC : IDriver {
        #region IDriver 成员

        public IDbConnection Connection {
            get { return new OdbcConnection(); }
        }

        public IDbDataAdapter DataAdapter(IDbCommand cmd) {
            OdbcDataAdapter da = new OdbcDataAdapter();
            da.SelectCommand = (OdbcCommand)cmd;
            return da;
        }

        public IDbCommand Command {
            get { return new OdbcCommand(); }
        }

        public string ReplaceSql(string sql) {
            return Regex.Replace(sql, "@[a-zA-z_0-9]+", "?", RegexOptions.IgnoreCase);
        }

        public IDataParameter CreateParameter(string name, object value, ParameterDirection direction) {
            OdbcParameter op = new OdbcParameter();
            op.ParameterName = "?";
            op.Value = value;
            if (value == null)
                op.Value = DBNull.Value;
            op.Direction = direction;
            return op;

        }

        #endregion


        public IDataParameter CreateProcParameter(string name, object value, ParameterDirection direction)
        {
            OdbcParameter op = new OdbcParameter();
            op.ParameterName = "?";
            op.Value = value;
            if (value == null)
                op.Value = DBNull.Value;
            op.Direction = direction;
            return op;
        }
    }
 
    /// <summary> 
    /// 命令执行描述
    /// </summary>
    public interface ICommandExecute {
        int Execute(IConnectinContext cc);
    }
    /// <summary>
   
    /// 添加数据命令
    /// </summary>
    public class Insert:ICommandExecute {

        
        public Insert(string table) {

            mTable = table;
           
        }
        private string mTable;
        private IList<Field> mInserFields = new List<Field>();
        public Insert AddField(string name, object value)
        {
            AddField(name, value, true);
            return this;
        }
        public Insert AddField(string name, object value, bool isparameter)
        {
            Field f = new Field();
            f.IsParameter = isparameter;
            f.Name = name;
            f.Value = value;
            mInserFields.Add(f);
            return this;
        }
        public int Execute(IConnectinContext cc) {
            Command mCommand = Command.GetThreadCommand().AddSqlText("Insert into ").AddSqlText( mTable);
            System.Text.StringBuilder names, values;
            names = new System.Text.StringBuilder();
            values = new System.Text.StringBuilder();
            Field field;
            for (int i = 0; i < mInserFields.Count; i++) {
                if (i > 0) {
                    names.Append(",");
                    values.Append(",");
                }
                field = (Field)mInserFields[i];

                names.Append(field.Name);
                if (field.IsParameter) {
                    values.Append("@").Append(field.ParameterName);
                    if (field.Value != null)
                        mCommand.AddParameter(field.ParameterName, field.Value);
                    else
                        mCommand.AddParameter(field.ParameterName, DBNull.Value);
                } else
                    values.Append(field.Value);

            }
            mCommand.Text.Append("(").Append(names).Append(")").Append(" Values(").Append(values).Append(")");
            return cc.ExecuteNonQuery(mCommand);
           

        }
    }
    /// <summary>
      /// 字段值描述
    /// </summary>
    public class Field {
        private object mValue;
        public object Value {
            get {
                return mValue;
            }
            set {
                mValue = value;
            }
        }
        private string mParameterName;
        public string ParameterName
        {
            get
            {
                return string.IsNullOrEmpty(mParameterName) ? Name : mParameterName;
            }
            set
            {
                mParameterName = value;
            }
        }
        private string mName;
        public string Name {
            get {
                return mName;
            }
            set {
                mName = value;
            }
        }
        private bool mIsParameter = true;
        public bool IsParameter {
            get {
                return mIsParameter;
            }
            set {
                mIsParameter = value;
            }
        }
        public string GetValueBy {
            get;
            set;
        }
        public bool GetValueAfterInsert {
            get;
            set;
        }
        
    }

    public class SQL
    {
        
        public SQL(string sql)
        {
            mBaseSql = sql;
            mCommand.AddSqlText(sql);
        }
        public static SQL operator +(string subsql, SQL sql)
        {
            sql.AddSql(subsql);
            return sql;
        }
        public static SQL operator +(SQL sql,string subsql)
        {
            sql.AddSql(subsql);
            return sql;
        }

        public SQL this[string name, object value]
        {
            get
            {
                return Parameter(name, value);
            }
        }

        public static implicit operator SQL(string sql)
        {
            return new SQL(sql);
        }

        private string mBaseSql;

        private Command mCommand = new Command("");

        public SQL AddSql(string sql)
        {
            mCommand.AddSqlText(sql);
            return this;
        }
        public SQL Parameter(string name, object value)
        {
            mCommand.AddParameter(name, value);
            return this;
        }

        public  int Execute()
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return Execute(cc);
            }
        }

        public  int Execute(IConnectinContext cc)
        {
            return cc.ExecuteNonQuery(mCommand);
        }

        public T GetValue<T>()
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return GetValue<T>(cc);
            }
        }

        public T GetValue<T>(IConnectinContext cc)
        {
            return (T)cc.ExecuteScalar(GetCommand());
        }

        public T ListFirst<T>() where T : new()
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return ListFirst<T>(cc);
            }
        }

        public T ListFirst<T>(IConnectinContext cc) where T : new()
        {
            IList<T> result = List<T>(cc, new Region(0,2));
            if (result.Count > 0)
                return result[0];
            return default(T);

        }

        public IList<T> List<T>() where T : new()
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return List<T>(cc);
            }
        }

        public IList<T> List<T>(Region region) where T : new()
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return List<T>(cc,region);
            }
        }

        public IList<T> List<T>(IConnectinContext cc) where T : new()
        {
            return List<T>(cc, null);
        }

        public IList<T> List<T>(IConnectinContext cc, Region region) where T : new()
        {
            List<T> result;
            if (region == null)
            {
             
                    region = new Region(0, 99999999);
              
            }
            if (region.Size > DBContext.DefaultListMaxSize)
                result = new List<T>(DBContext.DefaultListMaxSize);
            else
                result = new System.Collections.Generic.List<T>(region.Size);
            Mappings.CommandReader cr = Mappings.CommandReader.GetReader(mBaseSql, typeof(T));
            int index = 0;
            Command cmd = GetCommand();
            using (IDataReader reader = cc.ExecuteReader(cmd))
            {
                while (reader.Read())
                {
                    if (index >= region.Start)
                    {
                        T item = new T();
                        cr.ReaderToObject(reader, item);
                        result.Add(item);
                        if (result.Count >= region.Size)
                        {
                            cmd.DbCommand.Cancel();
                            reader.Dispose();
                            break;
                        }
                    }
                    index++;
                }
            }
            return result;
        }

        private Command GetCommand()
        {
            
            return mCommand;
        }
    }
   
    /// <summary>
     /// 更新数据命令
    /// </summary>
    public class Update:ICommandExecute {
  
        public Update(string table) {
           
            mTable = table;
        }
        private string mTable;
        private IList<Field> mFields = new List<Field>();
        public Update AddField(string name,string parametername, object value) {
            AddField(name,parametername, value, true);
            return this;
        }
        public Update AddField(string name, string parametername, object value, bool isparameter)
        {
            Field f = new Field();
            f.IsParameter = isparameter;
            f.Name = name;
            f.ParameterName = parametername;
            f.Value = value;
            mFields.Add(f);
            return this;
        }
        private Expression mWhere = new Expression();
        public Expression Where
        {
            get {
                return mWhere;
            }
            set {
                mWhere = value;
            }
        }
        #region ICommandExecute 成员
        public int Execute()
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
               return Execute(cc);
            }
        }
        public int Execute(IConnectinContext cc)
        {
            Command mCommand = Command.GetThreadCommand().AddSqlText("Update ").AddSqlText(mTable).AddSqlText(" set ");
            for (int i = 0; i < mFields.Count; i++) {
                if (i > 0)
                    mCommand.Text.Append(",");
                if (!mFields[i].IsParameter) {
                    mCommand.Text.Append(mFields[i].Name).Append("=").Append(mFields[i].Value);
                } else {
                    mCommand.Text.Append(mFields[i].Name).Append("=@").Append(mFields[i].ParameterName);
                    mCommand.AddParameter(mFields[i].ParameterName, mFields[i].Value);
                }
            }
            Where.Parse(mCommand);
            return cc.ExecuteNonQuery(mCommand);
            
        }

        #endregion
    }

    /// <summary>
    /// 删除数据命令
    /// </summary>
    public class Delete:ICommandExecute {
       
        public Delete(string table) {

            mTable = table;
           
        }
        private string mTable;
        private Expression mWhere = new Expression();
        public Expression Where
        {
            get
            {
                return mWhere;
            }
            set
            {
                mWhere = value;
            }
        }
        #region ICommandExecute 成员
        public int Execute()
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
               return Execute(cc);
            }
        }
        public int Execute(IConnectinContext cc) {
            Command mCommand= Command.GetThreadCommand().AddSqlText("Delete from ").AddSqlText(mTable);
            Where.Parse(mCommand);
            return cc.ExecuteNonQuery(mCommand);
          
        }

        #endregion
    }

    /// <summary>
    /// 数据加载区间描述
    /// </summary>
    [Serializable]
    public class Region
    {
        public Region()
        {
        }
        public Region(int pageindex,int size)
        {
            Size = size;
            Start = pageindex * size;
        }
        public int Start
        {
            get;
            set;
        }
        public int Size
        {
            get;
            set;
        }
    }


   


}
