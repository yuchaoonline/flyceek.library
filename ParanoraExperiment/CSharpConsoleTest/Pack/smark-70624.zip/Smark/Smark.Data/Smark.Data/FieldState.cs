﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Data
{
    /// <summary>
    /// 字段状态描述
    /// </summary>
    [Serializable]
    public class FieldState
    {
        public DateTime ModifyTime
        {
            get;
            set;
        }
    }
}
