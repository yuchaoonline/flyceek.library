﻿using System;
using System.Collections.Generic;
using System.Text;
using Smark.Data.Mappings;
namespace Smark.Data
{
    /// <summary>
    /// 条件表达式扩展操作
    /// </summary>
    public  partial class Expression
    {

        public IList<T> List<T>() where T : Mappings.DataObject, new()
        {
            return List<T>((Region)null);
        }
        public IList<T> List<T>(params string[] orderby) where T : Mappings.DataObject, new()
        {
            return List<T>(null as Region, orderby);
        }
        public IList<T> List<T>(Region region) where T : Mappings.DataObject, new()
        {
            return List<T>(region, null);
        }
        public IList<T> List<T>(Region region,params string[] orderby) where T : Mappings.DataObject,new()
        {
            ObjectMapper om = ObjectMapper.GetOM(typeof(T));
            using (IConnectinContext cc = om.Connection.GetContext())
            {
                return List<T>(cc, region, orderby);
            }
        }
        public IList<T> List<T>(IConnectinContext cc,params string[] orderby) where T : Mappings.DataObject, new()
        {
            return List<T>(cc, null, orderby);
        }
        public IList<T> List<T>(IConnectinContext cc,Region region) where T : Mappings.DataObject, new()
        {
            return List<T>(cc, region, null);
        }
        public IList<T> List<T>(IConnectinContext cc, Region region, params string[] orderby) where T : Mappings.DataObject,new()
        {
            Type type = typeof(T);
            ObjectMapper om = ObjectMapper.GetOM(type);
           
            SelectDataReader sr = om.GetSelectReader(type);
            string strob = null;
            if (orderby != null && orderby.Length > 0)
                strob= string.Join(",", orderby);
            return EntityBase.ExOnList<T>(cc, om.GetSelectTable(sr), this, region, strob, sr.Group);
        }
        public IList<RESULT> List<T, RESULT>() where T : Mappings.DataObject, new()
            where RESULT: new()
        {
            return List<T, RESULT>((Region)null);
        }
        public IList<RESULT> List<T, RESULT>(params string[] orderby) where T : Mappings.DataObject, new()
            where RESULT : new()
        {
            return List<T, RESULT>((Region)null, orderby);
        }
        public IList<RESULT> List<T, RESULT>(Region region) where T : Mappings.DataObject, new()
            where RESULT : new()
        {
            return List<T, RESULT>(region, null);
        }
        public IList<RESULT> List<T, RESULT>(Region region, params string[] orderby)
            where T : Mappings.DataObject, new()
            where RESULT : new()
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return List<T, RESULT>(cc, region, orderby);
            }
        }

        public IList<RESULT> List<T, RESULT>(IConnectinContext cc, Region region)
            where T : Mappings.DataObject, new()
            where RESULT : new()
        {
            return List<T, RESULT>(cc, region, null);
        }
        public IList<RESULT> List<T, RESULT>(IConnectinContext cc, params string[] orderby)
            where T : Mappings.DataObject, new()
            where RESULT : new()
        {
            return List<T, RESULT>(cc, null, orderby);
        }
        public IList<RESULT> List<T, RESULT>(IConnectinContext cc, Region region,params string[] orderby)
            where T : Mappings.DataObject, new()
            where RESULT : new()
        {
          
            Type type = typeof(RESULT);
            ObjectMapper om = ObjectMapper.GetOM(typeof(T));
            SelectDataReader sr = om.GetSelectReader(type);
            string strob = null;
            if (orderby != null && orderby.Length > 0)
                strob = string.Join(",", orderby);
            return EntityBase.ExOnList<RESULT>(cc, om.GetSelectTable(sr), this, region, strob, sr.Group);
            
        }

        public RESULT ListFirst<T, RESULT>()
            where T : Mappings.DataObject, new()
            where RESULT : new()
        {
            return ListFirst<T,RESULT>((string)null);
        }
        public RESULT ListFirst<T, RESULT>(IConnectinContext cc)
            where T : Mappings.DataObject, new()
            where RESULT : new()
        {
            return ListFirst<T,RESULT>(cc, null);
        }
        public RESULT ListFirst<T, RESULT>(params string[] orderby)
            where T : Mappings.DataObject, new()
            where RESULT : new()
        {

            ObjectMapper om = ObjectMapper.GetOM(typeof(T));
            using (IConnectinContext cc = om.Connection.GetContext())
            {
                return ListFirst<T,RESULT>(cc, orderby);
            }

        }
        public RESULT ListFirst<T, RESULT>(IConnectinContext cc, params string[] orderby)
            where T : Mappings.DataObject, new()
            where RESULT : new()
        {
            Type type = typeof(T);
            ObjectMapper om = ObjectMapper.GetOM(typeof(T));
            SelectDataReader sr = om.GetSelectReader(typeof(RESULT));
            string strob = null;
            if (orderby != null && orderby.Length > 0)
                strob = string.Join(",", orderby);
            return EntityBase.ExOnListFirst<RESULT>(cc, om.GetSelectTable(sr), this, strob, sr.Group);
        }


        public T ListFirst<T>() where T : Mappings.DataObject, new()
        {
            return ListFirst<T>((string)null);
        }
        public T ListFirst<T>(IConnectinContext cc) where T : Mappings.DataObject, new()
        {
            return ListFirst<T>(cc, null);
        }
        public T ListFirst<T>(params string[] orderby) where T : Mappings.DataObject, new()
        {

            ObjectMapper om = ObjectMapper.GetOM(typeof(T));
            using (IConnectinContext cc = om.Connection.GetContext())
            {
                return ListFirst<T>(cc, orderby);
            }

        }
        public T ListFirst<T>(IConnectinContext cc, params string[] orderby) where T:Mappings.DataObject,new()
        {
            Type type = typeof(T);
            ObjectMapper om = ObjectMapper.GetOM(typeof(T));
            SelectDataReader sr = om.GetSelectReader(type);
            string strob=null;
            if (orderby != null && orderby.Length > 0)
                strob = string.Join(",", orderby);
            return EntityBase.ExOnListFirst<T>(cc, om.GetSelectTable(sr), this, strob, sr.Group);
        }

        public int Delete<T>() where T : Mappings.DataObject
        {
            ObjectMapper om = ObjectMapper.GetOM(typeof(T));
            using (IConnectinContext cc = om.Connection.GetContext())
            {
               return Delete<T>(cc);
            }
        }
        public int Delete<T>(IConnectinContext cc) where T : Mappings.DataObject
        {
            ObjectMapper om = ObjectMapper.GetOM(typeof(T));
            return EntityBase.ExOnDelete(cc, om.Table, this);
        }
        public int Edit<T>(Action<T> handler) where T : DataObject, new()
        {
            T item = new T();
            handler(item);
            return  Edit<T>(item.GetChangeFields());
        }
        public int Edit<T>(IConnectinContext cc,Action<T> handler) where T : DataObject, new()
        {
            T item = new T();
            handler(item);
           return Edit<T>(cc,item.GetChangeFields());
        }
        public int Edit<T>(params Field[] fields) where T:DataObject,new()
        {
            ObjectMapper om = ObjectMapper.GetOM(typeof(T));
            using (IConnectinContext cc = om.Connection.GetContext())
            {
                return Edit<T>(cc,fields);
            }
        }
        public int Edit<T>(IConnectinContext cc, params Field[] fields)  where T:DataObject,new()
        {
            if (fields == null || fields.Length == 0)
                return 0;
            ObjectMapper om = ObjectMapper.GetOM(typeof(T));
            Update update = new Update(om.Table);
            update.Where = this;
            for (int i = 0; i < fields.Length;i++ )
            {
                Field f = fields[i];
                update.AddField(f.Name, f.ParameterName, Mappings.PropertyCastAttribute.CastValue(om, f.Name, f.Value));
            }
            return update.Execute(cc);   
        }

        public int Count<T>() where T : Mappings.DataObject
        {
            ObjectMapper om = ObjectMapper.GetOM(typeof(T));

            using (IConnectinContext cc = om.Connection.GetContext())
            {
                return Count<T>(cc);
            }
        }

        public int Count<T>(IConnectinContext cc) where T : Mappings.DataObject
        {
            Type type = typeof(T); 
            ObjectMapper om = ObjectMapper.GetOM(type);
            SelectDataReader sr = om.GetSelectReader(type);
            return EntityBase.ExOnCount(cc, om.Table, this, sr.Group);
        }

        public int Count<T>(string field) where T : Mappings.DataObject
        {
            return Count<T>(field, false);
        }

        public int Count<T>(string field, bool DISTINCT) where T : Mappings.DataObject
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return Count< T>(field, DISTINCT, cc);
            }
        }

        public int Count<T>(string field, IConnectinContext cc) where T : Mappings.DataObject
        {
            return Count<T>(field, false, cc);
        }

        public int Count<T>(string field, bool DISTINCT, IConnectinContext cc) where T : Mappings.DataObject
        {
            ObjectMapper om = ObjectMapper.GetOM(typeof(T));
            object value = EntityBase.ExOnAggregation(cc, om.Table, "count", field, DISTINCT, this, null);
            if (value == null || value == DBNull.Value)
                return 0;
            return (int)Convert.ChangeType(value, typeof(int));
        }

        public RESULT Sum<RESULT, Entity>(string field) where Entity : Mappings.DataObject
        {
            return Sum<RESULT, Entity>(field, false);
        }
        public RESULT Sum<RESULT, Entity>(string field, bool DISTINCT) where Entity : Mappings.DataObject
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return Sum<RESULT, Entity>(field, DISTINCT, cc);
            }
        }
        public RESULT Sum<RESULT, Entity>(string field, IConnectinContext cc) where Entity : Mappings.DataObject
        {
            return Sum<RESULT, Entity>(field, false, cc);
        }
        public RESULT Sum<RESULT, Entity>(string field, bool DISTINCT, IConnectinContext cc) where Entity : Mappings.DataObject
        {
            ObjectMapper om = ObjectMapper.GetOM(typeof(Entity));
            object value = EntityBase.ExOnAggregation(cc, om.Table, "Sum", field, DISTINCT, this,null);
            if(value == null || value == DBNull.Value)
                return default(RESULT);
            return (RESULT)Convert.ChangeType(value, typeof(RESULT));
        }
        public RESULT Max<RESULT, Entity>(string field) where Entity : Mappings.DataObject
        {
            return Max<RESULT, Entity>(field, false);
        }
        public RESULT Max<RESULT, Entity>(string field, bool DISTINCT) where Entity : Mappings.DataObject
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return Max<RESULT, Entity>(field, DISTINCT, cc);
            }
        }
        public RESULT Max<RESULT, Entity>(string field, IConnectinContext cc) where Entity : Mappings.DataObject
        {
            return Max<RESULT, Entity>(field, false, cc);
        }
        public RESULT Max<RESULT, Entity>(string field, bool DISTINCT, IConnectinContext cc) where Entity : Mappings.DataObject
        {
            ObjectMapper om = ObjectMapper.GetOM(typeof(Entity));
            object value = EntityBase.ExOnAggregation(cc, om.Table, "Max", field, DISTINCT, this, null);
            if (value == null || value == DBNull.Value)
                return default(RESULT);
            return (RESULT)Convert.ChangeType(value, typeof(RESULT));
        }
        public RESULT Min<RESULT, Entity>(string field) where Entity : Mappings.DataObject
        {
            return Min<RESULT, Entity>(field, false);
        }
        public RESULT Min<RESULT, Entity>(string field, bool DISTINCT) where Entity : Mappings.DataObject
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return Min<RESULT, Entity>(field, DISTINCT, cc);
            }
        }
        public RESULT Min<RESULT, Entity>(string field, IConnectinContext cc) where Entity : Mappings.DataObject
        {
            return Min<RESULT, Entity>(field, false, cc);
        }
        public RESULT Min<RESULT, Entity>(string field, bool DISTINCT, IConnectinContext cc) where Entity : Mappings.DataObject
        {
            ObjectMapper om = ObjectMapper.GetOM(typeof(Entity));
            object value = EntityBase.ExOnAggregation(cc, om.Table, "Min", field, DISTINCT, this, null);
            if (value == null || value == DBNull.Value)
                return default(RESULT);
            return (RESULT)Convert.ChangeType(value, typeof(RESULT));
        }
        public RESULT Avg<RESULT, Entity>(string field) where Entity : Mappings.DataObject
        {
            return Avg<RESULT, Entity>(field, false);
        }
        public RESULT Avg<RESULT, Entity>(string field, bool DISTINCT) where Entity : Mappings.DataObject
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return Avg<RESULT, Entity>(field, DISTINCT, cc);
            }
        }
        public RESULT Avg<RESULT, Entity>(string field, IConnectinContext cc) where Entity : Mappings.DataObject
        {
            return Avg<RESULT, Entity>(field, false, cc);
        }
        public RESULT Avg<RESULT, Entity>(string field, bool DISTINCT, IConnectinContext cc) where Entity : Mappings.DataObject
        {
            ObjectMapper om = ObjectMapper.GetOM(typeof(Entity));
            object value = EntityBase.ExOnAggregation(cc, om.Table, "Avg", field, DISTINCT, this, null);
            if (value == null || value == DBNull.Value)
                return default(RESULT);
            return (RESULT)Convert.ChangeType(value, typeof(RESULT));
        }
        #region GetValue
        public RESULT GetValue<RESULT, Entity>(FieldInfo field) where Entity : Mappings.DataObject
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return GetValue<RESULT, Entity>(field);
            }
        }
        public RESULT GetValue<RESULT, Entity>(FieldInfo field, IConnectinContext cc, params string[] orderby) where Entity : Mappings.DataObject
        {
            Command cmd = Command.GetThreadCommand();
            ObjectMapper om = ObjectMapper.GetOM(typeof(Entity));
            cmd.Text.AppendFormat("select {0} from {1} ", field.Name, om.Table);
            this.Parse(cmd);
            if (orderby != null && orderby.Length > 0)
                cmd.Text.Append(" Order by ").Append(string.Join(",", orderby));
            return cc.GetValue<RESULT>(cmd);

        }
        public IList<RESULT> GetValues<RESULT, Entity>(FieldInfo field) where Entity : Mappings.DataObject
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return GetValues<RESULT, Entity>(field, cc,(Region)null);
            }
        }
        public IList<RESULT> GetValues<RESULT, Entity>(FieldInfo field,params string[] orderby) where Entity : Mappings.DataObject
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return GetValues<RESULT, Entity>(field, cc, (Region)null,orderby);
            }
        }
        public IList<RESULT> GetValues<RESULT, Entity>(FieldInfo field, int pageindex, int pagesize,params string[] orderby) where Entity : Mappings.DataObject
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return GetValues<RESULT, Entity>(field, cc, new Region(pageindex, pagesize),orderby);
            }
        }
        public IList<RESULT> GetValues<RESULT, Entity>(FieldInfo field,int pageindex,int pagesize) where Entity : Mappings.DataObject
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return GetValues<RESULT, Entity>(field, cc,new Region(pageindex,pagesize));
            }
        }
        public IList<RESULT> GetValues<RESULT, Entity>(FieldInfo field, IConnectinContext cc, int pageindex, int pagesize) where Entity : Mappings.DataObject
        {
            return GetValues<RESULT, Entity>(field, cc, new Region(pageindex,pagesize));
        }
        public IList<RESULT> GetValues<RESULT, Entity>(FieldInfo field, Region region) where Entity : Mappings.DataObject
        {
            using (IConnectinContext cc = DBContext.Context1)
            {
                return GetValues<RESULT, Entity>(field, cc, region);
            }
        }
        public IList<RESULT> GetValues<RESULT, Entity>(FieldInfo field, IConnectinContext cc, Region region,params string[] orderby) where Entity : Mappings.DataObject
        {
            Command cmd = Command.GetThreadCommand();
            ObjectMapper om = ObjectMapper.GetOM(typeof(Entity));
            cmd.Text.AppendFormat("select {0} from {1} ", field.Name, om.Table);
            this.Parse(cmd);
            if(orderby !=null && orderby.Length >0)
                cmd.Text.Append(" Order by ").Append(string.Join(",",orderby));
            return cc.GetValues<RESULT>(cmd, region);
        }
        #endregion
    }
}
