﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data.Odbc;
namespace Smark.Data
{
    /// <summary>
    /// 数据库提供者模板
    /// </summary>
    /// <typeparam name="Conn">数据库连接对象</typeparam>
    /// <typeparam name="Cmd">数据库命令执行对象</typeparam>
    /// <typeparam name="Adapter">数据适配器</typeparam>
    /// <typeparam name="Parameter">命令参数对象</typeparam>
    /// <typeparam name="Sqlbuilder">Sql构建器</typeparam>
    public class DriverTemplate<Conn, Cmd, Adapter, Parameter, Sqlbuilder> : IDriver
        where Conn : IDbConnection, new()
        where Cmd : IDbCommand, new()
        where Adapter : IDbDataAdapter, new()
        where Parameter : IDataParameter, new()
        where Sqlbuilder : ISQLBuilder, new()
    {
        #region IDriver 成员

        protected ISQLBuilder mBuilder = new Sqlbuilder();
        public IDbConnection Connection
        {
            get { return new Conn(); }
        }

        public IDbDataAdapter DataAdapter(IDbCommand cmd)
        {
            IDbDataAdapter da = new Adapter();
            da.SelectCommand = cmd;
            return da;
        }

        public IDbCommand Command
        {
            get { return new Cmd(); }
        }

        public string ReplaceSql(string sql)
        {
            return mBuilder.ReplaceSql(sql);
        }
        public virtual IDataParameter  CreateProcParameter(string name, object value, ParameterDirection direction)
        {
            IDataParameter dp = new Parameter();
            mBuilder.SetProcParameter(dp, name, value, direction);
            return dp;
        }
        public virtual IDataParameter CreateParameter(string name, object value, ParameterDirection direction)
        {
            IDataParameter dp = new Parameter();
            mBuilder.SetParameter(dp, name, value, direction);
            return dp;
        }

        #endregion
    }
}
