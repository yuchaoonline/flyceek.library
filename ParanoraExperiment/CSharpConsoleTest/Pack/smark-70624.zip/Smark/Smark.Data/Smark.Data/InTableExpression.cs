﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Data
{
    public class InTableExpression
    {
        
        public FieldInfo Field
        {
            get;
            set;
        }
        public Expression Expression
        {
            get;
            set;
        }
    }
}
