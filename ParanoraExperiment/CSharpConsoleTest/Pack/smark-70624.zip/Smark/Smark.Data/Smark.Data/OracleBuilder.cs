﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
namespace Smark.Data
{
    public class OracleBuilder : ISQLBuilder
    {

        #region ISQLBuilder 成员

        public string ReplaceSql(string sql)
        {
            return sql.Replace("@", ":");
        }

        public void SetParameter(IDataParameter dp, string name, object value, ParameterDirection direction)
        {
            dp.ParameterName = ":" + name;
            if (value == null)
                dp.Value = DBNull.Value;
            else
                dp.Value = value;
            dp.Direction = direction;
        }

        #endregion


        public void SetProcParameter(IDataParameter dp, string name, object value, ParameterDirection direction)
        {
            dp.ParameterName =  name;
            if (value == null)
                dp.Value = DBNull.Value;
            else
                dp.Value = value;
            dp.Direction = direction;
        }
    }
}
