﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
namespace Smark.Data
{
    /// <summary>
    /// 命令处理对象
    /// </summary>
    public class Command
    {
        public Command(string text)
        {
            Text.Append(text);

        }

        private System.Text.StringBuilder mText = new System.Text.StringBuilder(256);
        //存储SQL
        public System.Text.StringBuilder Text
        {
            get
            {
                return mText;
            }

        }
        private CommandType mCommandType = CommandType.Text;
        //执行命令类型
        public CommandType CommandType
        {
            get
            {
                return mCommandType;
            }
            set
            {
                mCommandType = value;
            }

        }
        //设置或获取相关命令对象
        public IDbCommand DbCommand
        {
            get;
            set;
        }
        private IList<Parameter> mParameters = new List<Parameter>();
        //命令参数
        protected IList<Parameter> Parameters
        {
            get
            {
                return mParameters;
            }
        }
        //添加参数
        public Command AddParameter(string name, object value)
        {
          return  AddParameter(name, value, ParameterDirection.Input);
            
        }
        //添加参数
        public Command AddParameter(Parameter parameter)
        {
            Parameters.Add(parameter);
            return this;
        }
        //添加参数
        public Command AddParameter(string name, object value, ParameterDirection pd)
        {
            Parameter p = new Parameter();
            p.Name = name;
            p.Value = value;
            p.Direction = pd;
            Parameters.Add(p);
            return this;
        }

        public Command AddSqlText(string text)
        {
            Text.Append(text);
            return this;
        }
        //清空参数
        public void ClearParameter()
        {
            Parameters.Clear();
        }

        public void Clean()
        {
            ClearParameter();
#if NET_4
            Text.Clear();
#else
            Text.Remove(0, Text.Length);
#endif

        }

        [Serializable]
        public class Parameter
        {
            private string mName;
            public string Name
            {
                get
                {
                    return mName;
                }
                set
                {
                    mName = value;
                }
            }
            private object mValue;
            public object Value
            {
                get
                {
                    return mValue;
                }
                set
                {
                    mValue = value;
                }
            }
            private ParameterDirection mDirection = ParameterDirection.Input;
            public ParameterDirection Direction
            {
                get
                {
                    return mDirection;
                }
                set
                {
                    mDirection = value;
                }
            }
        }

        public IDbCommand CreateCommand(IDriver driver)
        {
            IDbCommand cmd = driver.Command;
            cmd.CommandText = driver.ReplaceSql(Text.ToString());
            cmd.CommandType = CommandType;
            DbCommand = cmd;
            for(int i =0;i<Parameters.Count;i++)
            {
                Parameter p = Parameters[i];
                cmd.Parameters.Add(driver.CreateParameter(p.Name, p.Value, p.Direction));

            }
            return cmd;
        }

        [ThreadStatic]
        private static Command mThreadCommand;

        public static Command GetThreadCommand()
        {
            if (mThreadCommand == null)
                mThreadCommand = new Command("");
            mThreadCommand.Clean();
            return mThreadCommand;
        }
    }
}
