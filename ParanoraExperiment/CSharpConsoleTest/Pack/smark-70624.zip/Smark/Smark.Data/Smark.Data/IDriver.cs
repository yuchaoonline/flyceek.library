﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
namespace Smark.Data
{
    /// <summary>
    /// 数据库设备描述接口
    /// </summary>
    public interface IDriver
    {
        IDbConnection Connection
        {
            get;
        }
        IDbDataAdapter DataAdapter(IDbCommand cmd);
        IDbCommand Command
        {
            get;
        }
        string ReplaceSql(string sql);
        System.Data.IDataParameter CreateProcParameter(string name, object value, ParameterDirection direction);
        System.Data.IDataParameter CreateParameter(string name, object value, ParameterDirection direction);

    }
}
