﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Data.Mappings
{
    public class TableAttribute:Attribute
    {
        public TableAttribute()
        {
            DISTINCT = false;
            DefaultConnection = ConnectionType.Context1;
        }
        public TableAttribute(string name)
        {
            Name = name;
        }
       
        public string Name
        {
            get;
            set;
        }
        public bool DISTINCT
        {
            get;
            set;
        }
        public ConnectionType DefaultConnection
        {
            get;
            set;
        }
        
    }
}
