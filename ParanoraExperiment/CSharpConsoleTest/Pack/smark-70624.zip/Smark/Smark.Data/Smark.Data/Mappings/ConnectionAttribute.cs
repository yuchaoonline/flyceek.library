﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Data.Mappings
{
    [AttributeUsage(AttributeTargets.Class| AttributeTargets.Interface)]
    public class ConnectionAttribute:Attribute
    {
        public ConnectionAttribute(ConnectionType type)
        {
            Type = type;
        }

        public ConnectionType Type
        {
            get;
            set;
        }

        public static IConnectinContext GetContext(ConnectionType type)
        {
            return DBContext.GetConnection(type);
        }

        public IConnectinContext GetContext()
        {
            return GetContext(Type);
        }
    }
    
}
