﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Data.Mappings
{
    public interface ITableObject
    {
    }
}
