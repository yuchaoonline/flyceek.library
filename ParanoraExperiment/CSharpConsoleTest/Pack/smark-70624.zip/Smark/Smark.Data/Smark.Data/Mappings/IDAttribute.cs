﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Data.Mappings
{
    [AttributeUsage(AttributeTargets.Property)]
    public class IDAttribute:Attribute
    {
        public IDAttribute()
        {
           
        }
        public IDAttribute(string name)
        {
            Name = name;
        }
        public string Name
        {
            get;
            set;
        }
    }
}
