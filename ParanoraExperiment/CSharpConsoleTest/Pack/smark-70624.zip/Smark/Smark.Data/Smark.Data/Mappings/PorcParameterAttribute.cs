﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Data.Mappings
{
    [AttributeUsage(AttributeTargets.Property)]
    public class ProcParameterAttribute:Attribute
    {
        
        public string Name
        {
            get;
            set;
        }
        public System.Data.ParameterDirection Direction
        {
            get;
            set;
        }
        public bool Output
        {
            get;
            set;
        }
        public Smark.Core.PropertyHandler Handler
        {
            get;
            set;
        }
    }
}
