﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Data.Mappings
{
    public class PropertyMapper
    {
        public PropertyMapper()
        {
           
        }
        //public int ColumnIndex
        //{
        //    get;
        //    set;
        //}
        public string ColumnName
        {
            get;
            set;
        }
        public Smark.Core.PropertyHandler Handler
        {
            get;
            set;
        }
        public PropertyCastAttribute Cast
        {
            get;
            set;
        }
        public AggregationAttribute Aggregation
        {
            get;
            set;
        }
        public ValueAttribute Value
        {
            get;
            set;
        }
        public override bool Equals(object obj)
        {
            PropertyMapper pm = (PropertyMapper)obj;
            return pm.ColumnName == this.ColumnName;
            
        }
        internal ObjectMapper OM
        {
            get;
            set;
        }
        public Validates.ValidaterAttribute[] Validaters
        {
            get;
            set;
        }
    }
}
