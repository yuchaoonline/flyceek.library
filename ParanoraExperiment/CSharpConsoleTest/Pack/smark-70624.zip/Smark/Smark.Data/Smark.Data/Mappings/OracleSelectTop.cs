﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Smark.Data.Mappings
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface)]
    public class OracleSelectTop : Smark.Data.Mappings.SelectChangeAttribute
    {
        public OracleSelectTop(int max)
        {
            Max = max;
        }
        public int Max
        {
            get;
            set;
        }
        public override void Change(Smark.Data.Command cmd)
        {
            string sql =string.Format("select * from ({0}) where rownum <{1}",cmd.Text.ToString(),Max);
#if NET_4
            cmd.Text.Clear();
#else
            cmd.Text.Remove(0, cmd.Text.Length);
#endif
           
            cmd.Text.Append(sql);
           
        }
    }
}
