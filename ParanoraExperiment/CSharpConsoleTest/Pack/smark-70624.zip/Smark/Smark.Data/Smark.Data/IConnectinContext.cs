﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
namespace Smark.Data
{
    /// <summary>
    /// 数据连接上下文对象基于线程存储
    /// </summary>
    public interface IConnectinContext : IDbTransaction, IDisposable
    {
        void BeginTransaction(IsolationLevel level);
        void BeginTransaction();
        int ExecuteNonQuery(Command cmd);
        IDataReader ExecuteReader(Command cmd);
        object ExecuteScalar(Command cmd);
        DataSet ExecuteDataSet(Command cmd);
        IList<T> List<T>(Command cmd, Region region) where T :  new();
        object ExecProc(object parameter);
        IList<T> ListProc<T>(object parameter) where T : new();
        T ListFirst<T>(Command cmd) where T :  new();
        T Load<T>(Command cmd) where T : IEntityState, new();

        IList List(Type type, Command cmd, Region region);
        object ListFirst(Type type, Command cmd);
        object Load(Type type, Command cmd);
        ConnectionType Type
        {
            get;
            set;
        }
        #region GetValue
        T GetValue<T>(Command cmd);
        IList<T> GetValues<T>(Command cmd);
        IList<T> GetValues<T>(Command cmd, Region region);
        #endregion
    }
}
