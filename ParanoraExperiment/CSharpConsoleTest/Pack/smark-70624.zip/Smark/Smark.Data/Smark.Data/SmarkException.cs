﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Data
{
    public class SmarkDataException:Exception
    {
        public SmarkDataException() { }
        public SmarkDataException(string err) : base(err) { }
        public SmarkDataException(string err, Exception baseexc) : base(err, baseexc) { }
    }
}
