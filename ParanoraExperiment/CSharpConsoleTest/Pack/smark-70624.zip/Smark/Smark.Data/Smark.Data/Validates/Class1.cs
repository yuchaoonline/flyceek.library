﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Text.RegularExpressions;
namespace Smark.Data.Validates
{
    public class ValidaterException :SmarkDataException
    {
        public ValidaterException() { }
        public ValidaterException(string err) : base(err) { }
        public ValidaterException(string err, Exception baseexc) : base(err, baseexc) { }
    }
    [AttributeUsage(AttributeTargets.Property)]
    public abstract class ValidaterAttribute : Attribute
    {
        public bool Validating(object value, object source,Mappings.PropertyMapper pm,IConnectinContext cc )
        {
            return OnValidating(value, source, pm, cc);
               
        }

        protected abstract bool OnValidating(object value, object source, Mappings.PropertyMapper pm, IConnectinContext cc);

        public string Message
        {
            get;
            set;
        }

    }
    [AttributeUsage(AttributeTargets.Property)]
    public class NotNull : ValidaterAttribute
    {
        public NotNull()
        {

        }
        public NotNull(string message)
        {
            Message = message;
        }
        protected override bool OnValidating(object value, object source, Mappings.PropertyMapper pm, IConnectinContext cc)
        {
            bool result= value != null && !string.IsNullOrEmpty(value.ToString());
            if (!result && string.IsNullOrEmpty(Message))
                Message = string.Format("{0}成员值不能为空!", pm.ColumnName);
            return result;
        }
    }

    [AttributeUsage(AttributeTargets.Property)]
    public class Length : ValidaterAttribute
    {

        public Length(string min, string max, string message)
        {
            if (!string.IsNullOrEmpty(min))
                MinLength = int.Parse(min);
            if (!string.IsNullOrEmpty(max))
                MaxLength = int.Parse(max);
            Message = message;
        }
        public int? MinLength
        {
            get;
            set;
        }
        public int? MaxLength
        {
            get;
            set;
        }
        protected override bool OnValidating(object value, object source, Mappings.PropertyMapper pm, IConnectinContext cc)
        {
           
            if (value != null && !string.IsNullOrEmpty(value.ToString()))
            {
                string data = Convert.ToString(value);
                if (MinLength != null && MinLength > data.Length)
                {

                    return false;
                }

                if (MaxLength != null && data.Length > MaxLength)
                {

                    return false;

                }
            }
            return true;
        }
      
    }

    [AttributeUsage(AttributeTargets.Property)]
    public class NumberRegion : ValidaterAttribute
    {

        public NumberRegion(string min, string max, string message)
        {
         
            if (!string.IsNullOrEmpty(min))
                MinValue = int.Parse(min);
            if (!string.IsNullOrEmpty(max))
                MaxValue = int.Parse(max);
            Message = message;
        }

        public int? MinValue
        {
            get;
            set;
        }
        public int? MaxValue
        {
            get;
            set;
        }
        protected override bool OnValidating(object value, object source, Mappings.PropertyMapper pm, IConnectinContext cc)
        {
            
            if (value != null && !string.IsNullOrEmpty(value.ToString()))
            {
                int data = Convert.ToInt16(value);
                if (MinValue != null)
                {
                    if (MinValue > data)
                    {
                        return false;
                    }
                }

                if (MaxValue != null)
                {
                    if (data > MaxValue)
                    {
                        return false;
                    }
                }
            }

            return true;
        }
        
    }

    [AttributeUsage(AttributeTargets.Property)]
    public class DateRegion : ValidaterAttribute
    {

        public DateRegion(string mindate, string maxdate, string message)
        {
            if (!string.IsNullOrEmpty(mindate))
                MinValue = DateTime.Parse(mindate);
            if (!string.IsNullOrEmpty(maxdate))
                MaxValue = DateTime.Parse(maxdate);

            Message = message;
        }
        public DateTime? MinValue
        {
            get;
            set;
        }
        public DateTime? MaxValue
        {
            get;
            set;
        }
        protected override bool OnValidating(object value, object source, Mappings.PropertyMapper pm, IConnectinContext cc)
        {
           
            if (value != null && !string.IsNullOrEmpty(value.ToString()))
            {
                DateTime data = Convert.ToDateTime(value);
                if (MinValue != null)
                {
                    if (MinValue >data)
                    {
                        return false;
                    }
                }

                if (MaxValue != null)
                {
                    if (data > MaxValue)
                    {
                        return false;
                    }
                }
            }

            return true;
        }
        
    }
    [AttributeUsage(AttributeTargets.Property)]
    public class Match : ValidaterAttribute
    {
        public Match(string regex, string message)
        {
            Regex = regex;
            Message = message;
        }
        public string Regex
        {
            get;
            set;
        }
        protected override bool OnValidating(object value, object source, Mappings.PropertyMapper pm, IConnectinContext cc)
        {
           
            if (value != null && !string.IsNullOrEmpty(value.ToString()))
            {
                string data = Convert.ToString(value);
                if (System.Text.RegularExpressions.Regex.Match(
                    data, Regex, RegexOptions.IgnoreCase).Length == 0)
                {
                    return false;
                }

            }
            return true;
        }
       
    }
    [AttributeUsage(AttributeTargets.Property)]
    public class EMail : Match
    {
        public EMail(string msg) : base(@"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", msg) { }
    }
    [AttributeUsage(AttributeTargets.Property)]
    public class CardID : Match
    {
        public CardID(string msg) : base(@"^(\d{15}$|^\d{18}$|^\d{17}(\d|X|x))$/", msg) { }
    }

    [AttributeUsage(AttributeTargets.Property)]
    public class Unique : ValidaterAttribute
    {
        public Unique(string err)
        {
            Message = err;
        }
        protected override bool OnValidating(object value, object source, Mappings.PropertyMapper pm, IConnectinContext cc)
        {
            if (value == null)
                return true;
            if (string.IsNullOrEmpty((string)value))
                return true;
            string sql = "select {0} from {1} where {0}=@p1";
            Command cmd = new Command(string.Format(sql, pm.ColumnName, pm.OM.Table));
            cmd.AddParameter("p1", value);
            object result = cc.ExecuteScalar(cmd);
            return result == null || result == DBNull.Value;

        }
    }

    public class ValidaterError
    {
        public string Name
        {
            get;
            set;
        }
        public string Error
        {
            get;
            set;
        }
    }
}
