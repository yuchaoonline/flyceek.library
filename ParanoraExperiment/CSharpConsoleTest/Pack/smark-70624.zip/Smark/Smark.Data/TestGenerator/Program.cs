﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestGenerator
{
    class Program
    {
        static void Main(string[] args)
        {
            string code;
            System.IO.FileStream stream = System.IO.File.Open("c:\\DBModule.cs", System.IO.FileMode.Open);
                Smark.Data.InterfaceToModelGenerator.GenerateCode gc = new Smark.Data.InterfaceToModelGenerator.GenerateCode();
                System.IO.Stream st = gc.Builder(stream);
                st.Seek(0, System.IO.SeekOrigin.Begin);
                using (System.IO.StreamReader r = new System.IO.StreamReader(st))
                {
                    code = r.ReadToEnd();

                }
                
           
            Console.Read();
        }
    }
}
