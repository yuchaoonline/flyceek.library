﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
namespace Smark.Net.Tcp.XmlServices
{
    public class XmlWriterHelper
    {
        public XmlWriterHelper(XmlTextWriter writer)
        {
            mWriter = writer;
        }
        protected XmlTextWriter mWriter;
        public XmlWriterHelper Start(string name)
        {
            mWriter.WriteStartElement(name);
            return this;
        }
        public XmlWriterHelper End()
        {
            mWriter.WriteEndElement();
            return this;
        }
        public XmlWriterHelper Element(string name, object value)
        {
            mWriter.WriteStartElement(name);
            mWriter.WriteValue(value);
            mWriter.WriteEndElement();
            return this;
        }
        public XmlWriterHelper Element(string name, Action<XmlWriterHelper> handler)
        {
            Start(name);
            handler(this);
            End();
            return this;
        }
    }
    public class XmlReaderHelper
    {
        public XmlReaderHelper(XmlTextReader reader)
        {
            mReader = reader;
        }
        protected XmlTextReader mReader;
        public XmlReaderHelper Start()
        {
            mReader.ReadStartElement();
            return this;
        }
        public XmlReaderHelper End()
        {
            mReader.ReadEndElement();
            return this;
        }
        public string Element()
        {
            string result = null;
            Start();
            result = mReader.ReadString();
            End();
            return result;

        }
        public void Element(Action<XmlReaderHelper> handler)
        {
            Start();
            handler(this);
            End();

        }
    }
}
