﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.XmlServices
{
    [AttributeUsage(AttributeTargets.Method,AllowMultiple=true)]
    public class SkipFilter:Attribute
    {
        public SkipFilter(params Type[] type)
        {
            FilterType = type;
        }
        public Type[] FilterType
        {
            get;
            set;
        }
    }
}
