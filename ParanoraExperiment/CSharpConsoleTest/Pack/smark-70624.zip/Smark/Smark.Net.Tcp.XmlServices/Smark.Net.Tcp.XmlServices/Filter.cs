﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.XmlServices
{
    [AttributeUsage(AttributeTargets.Class| AttributeTargets.Method)]
    public abstract class Filter:Attribute
    {
        public abstract void Execute(ActionContext context);
        public override bool Equals(object obj)
        {
            return GetType() == obj.GetType();
        }
        public override int GetHashCode()
        {
            return GetType().GetHashCode();
        }
    }
}
