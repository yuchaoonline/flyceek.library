﻿using System;
using System.Collections.Generic;
using System.Text;
using Smark.Net.Tcp;
namespace Smark.Net.Tcp.XmlServices
{
    public class XmlMessageEof : EofAdapter
    {
        private byte[] mEofData;
        public override byte[] EofData
        {
            get
            {
                if (mEofData == null)
                    mEofData = Coding.GetBytes("</xml-message>");
                return mEofData;
            }
        }
    }
}
