﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
namespace Smark.Net.Tcp.XmlServices
{
    [AttributeUsage(AttributeTargets.Class)]
    public class MessageConversion :Attribute
    {
        #region IMessageConversion 成员

        public virtual void ToXML(XmlTextWriter writer, IXmlMessage message)
        {
       
            message.SaveData(writer);
           
        }

        public virtual void ToObject(XmlTextReader reader, IXmlMessage message)
        {

            message.LoadData(reader);
        }

        #endregion
    }
}
