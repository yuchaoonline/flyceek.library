﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.XmlServices
{
    public interface IChannelEvent
    {
         void ClientDisposed(XmlChannel channel);
         void ClientConnected(XmlChannel channel);
         void Error(Exception error, XmlChannel channel);
         void Process(IXmlMessage message, PacketInfo info);
    }
    class ChannelEvent : IChannelEvent
    {
        #region IChannelEvent 成员

        public void ClientDisposed(XmlChannel channel)
        {
            
        }

        public void ClientConnected(XmlChannel channel)
        {
           
        }

        public void Error(Exception error, XmlChannel channel)
        {
            
        }

        public void Process(IXmlMessage message, PacketInfo info)
        {
            
        }

        #endregion
    }
}
