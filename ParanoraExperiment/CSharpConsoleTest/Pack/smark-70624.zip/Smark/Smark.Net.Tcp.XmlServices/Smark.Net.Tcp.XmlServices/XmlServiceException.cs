﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.XmlServices
{
    public class XmlServiceException:Exception
    {
        public XmlServiceException()
        {
        }
        public XmlServiceException(string msg)
            : base(msg)
        {
        }
        public int ErrorCode
        {
            internal set;
            get;
        }
        public static XmlServiceException ActionNotFound(Type type)
        {
            XmlServiceException err = new XmlServiceException(string.Format("{0} Action not found!",type.FullName));
            err.ErrorCode = ACTION_NOT_FOUND;
            
            return err;
            
        }
        public static XmlServiceException ActionNotFound(string type)
        {
            XmlServiceException err = new XmlServiceException(string.Format("{0} Action not found!", type));
            err.ErrorCode = ACTION_NOT_FOUND;
            
            return err;

        }
        public static XmlServiceException ActionProcessError(Type type,Exception baseerror)
        {
            XmlServiceException err = new XmlServiceException(baseerror,string.Format("{0} Action process error!", type.FullName));
            err.ErrorCode = ACTION_PROCESS_ERROR;
            return err;

        }
        public XmlServiceException(Exception innererr, string msg) : base(msg, innererr) { }
        public const int ACTION_NOT_FOUND = 0x1001;
        public const int ACTION_PROCESS_ERROR = 0x1004;
    }
}
