﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.XmlServices
{
    public delegate void XmlChannelEventHandler(object sender,XmlChannelArgs e);
     public class XmlChannelArgs : EventArgs
    {
        public XmlChannelArgs(XmlChannel channel)
        {
            mChannel = channel;
        }
        private XmlChannel mChannel;
        public XmlChannel Channel
        {
            get
            {
                return mChannel;
            }
        }
    }
    
}
