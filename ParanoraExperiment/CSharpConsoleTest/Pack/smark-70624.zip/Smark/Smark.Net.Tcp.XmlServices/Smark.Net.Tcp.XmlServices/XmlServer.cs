﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using Smark.Net.Tcp;
namespace Smark.Net.Tcp.XmlServices
{
    public class XmlServer:IDisposable
    {
     
        public XmlServer()
		{
			mChannels = new System.Collections.Hashtable(Smark.Net.Tcp.Utils.Connections);
		}
		private System.Collections.Hashtable mChannels;
        private Smark.Net.Tcp.TcpServer mServer = new Smark.Net.Tcp.TcpServer();
        public void Open(string ip, int port)
        {
            mServer.Open(ip, port);
            ServerInit(mServer);
        }
        public void Open(IPAddress ipaddress, int port)
        {
            mServer.Open(new IPEndPoint(ipaddress, port));
            ServerInit(mServer);
        }
        public void Open(IPEndPoint endpoing)
        {
            mServer.Open(endpoing);
            ServerInit(mServer);
        }
        private void ServerInit(Smark.Net.Tcp.TcpServer server)
        {
            server.ChannelConnected += OnClientConnected;
            
        }
        public static XmlChannel CreateChannel(string ip, int port)
        {
            return CreateChannel(IPAddress.Parse(ip), port);
        }
        public static XmlChannel CreateChannel(IPAddress ipaddress, int port)
        {
            return CreateChannel(new IPEndPoint(ipaddress,port));
        }
        public static XmlChannel CreateChannel(IPEndPoint point)
        {
            Smark.Net.Tcp.TcpChannel channel = Smark.Net.Tcp.TcpServer.CreateClient(point);
            return new XmlChannel(channel);
        }
        private void OnClientConnected(object source, ChannelEventArgs e)
        {


            XmlChannel channel = new XmlChannel(e.Channel);
            lock (mChannels.SyncRoot)
            {
                mChannels.Add(e.Channel.ClientID, channel);
            }
            ServiceUtils.ChannelEvent.ClientConnected(channel);
           
        }


        private bool mDisposed = false;
        public void Dispose()
        {
            lock (this)
            {
                if (!mDisposed)
                {
                    mServer.Dispose();
                    mServer = null;
                    mDisposed = true;
                }
            }
        }
        public void Close()
        {
            Dispose();
        }
    }
}
