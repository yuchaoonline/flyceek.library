﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.XmlServices
{
    [AttributeUsage(AttributeTargets.Class)]
    public class Controller:Attribute
    {
    }
}
