﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
namespace Smark.Net.Tcp.XmlServices
{
    public class ServiceUtils
    {
        static ServiceUtils()
        {
            ChannelEvent = new ChannelEvent(); 
        }
        private static Dictionary<string, ActionContextFactory> mActionContexts = new Dictionary<string, ActionContextFactory>(500);
        public static void LoadAssembly(params System.Reflection.Assembly[] assemblies)
        {
            if (assemblies != null)
            {
                foreach (Assembly item in assemblies)
                {
                    OnLoadAssembly(item);
                }
            }
        }
        private static void OnLoadAssembly(Assembly item)
        {
            foreach (Type type in item.GetTypes())
            {
                if (type.GetInterface("Smark.Net.Tcp.XmlServices.IXmlMessage") != null)
                {
                    CreateActionContext(type);
                }
            }
            foreach (Type type in item.GetTypes())
            {
                Controller[] controllers= Smark.Core.Functions.GetTypeAttributes<Controller>(type, false);
                if (controllers != null && controllers.Length > 0)
                {
                    BuilderController(type);
                }
            }
        }
        public static void Execute(XmlMessageAdapter msgadapter, XmlChannel channel,PacketInfo packetinfo)
        {
          
            if(msgadapter.ContextFactory !=null)
            {
                try
                {
                    using (ActionContext ac = msgadapter.ContextFactory.Builder(msgadapter, channel, packetinfo))
                    {
                        ac.Execute();
                    }
                }
                catch (Exception e_)
                {
                    channel.Channel.CallChannelError(new ChannelErrorEventArgs() { Exception = e_, Channel = channel.Channel });
                }

            }
        }
        internal static ActionContextFactory GetActionContextFactory(Type type)
        {
            if (mActionContexts.ContainsKey(type.FullName))
                return mActionContexts[type.FullName];
            return null;
        }
        internal static ActionContextFactory GetActionContextFactory(string type)
        {
            if (mActionContexts.ContainsKey(type))
                return mActionContexts[type];
            return null;
        }
        private static void CreateActionContext(Type type)
        {
            if (!mActionContexts.ContainsKey(type.FullName))
            {
                MessageConversion[] convers = Smark.Core.Functions.GetTypeAttributes<MessageConversion>(type, false);
                ActionContextFactory acf = new ActionContextFactory();
                acf.ActionType = type;
                if (convers != null && convers.Length > 0)
                    acf.Conversion = convers[0];
                else
                    acf.Conversion = new MessageConversion();
                acf.ActionName = type.FullName + "," + type.Assembly.GetName().Name;
                mActionContexts.Add(type.FullName, acf);
                mActionContexts.Add(acf.ActionName, acf);
            }
        }
        private static void BuilderController(Type type)
        {
            foreach (MethodInfo method in type.GetMethods(BindingFlags.Public | BindingFlags.Instance))
            {
                IXmlMessage message = null;
                ParameterInfo[] parameters = method.GetParameters();
                ActionContextFactory acf;
                List<Filter> filters = new List<Filter>();
                if (parameters.Length == 2)
                {
                    if((parameters[0].ParameterType.GetInterface("Smark.Net.Tcp.XmlServices.IXmlMessage") != null && parameters[1].ParameterType == typeof(PacketInfo))

                      )
                    {
                        message = (IXmlMessage)Activator.CreateInstance(parameters[0].ParameterType);
                    }
                    else
                    {
                        message = null;
                    }
                    if (message != null)
                    {
                        acf = GetActionContextFactory(message.GetType());
                        if (acf != null)
                        {
                            foreach (Filter item in Smark.Core.Functions.GetTypeAttributes<Filter>(type, false))
                            {
                                filters.Add(item);
                            }
                            foreach (Filter item in Smark.Core.Functions.GetMethodAttributes<Filter>(method, false))
                            {
                                if (!filters.Contains(item))
                                    filters.Add(item);
                            }
                            foreach (SkipFilter skip in Smark.Core.Functions.GetMethodAttributes<SkipFilter>(method, false))
                            {
                                if (skip.FilterType != null)
                                {
                                    foreach (Type filtertype in skip.FilterType)
                                    {
                                        Filter f = (Filter)Activator.CreateInstance(filtertype);
                                        if (filters.Contains(f))
                                            filters.Remove(f);
                                    }
                                }
                            }
                            acf.Filters = filters;
                            acf.Method = method;
                            acf.MethodHandler = new Smark.Core.MethodHandler(method);
                            acf.Controller = Activator.CreateInstance(type);
                        }
                    }
                                      
                }

            }
        }
        public static IChannelEvent ChannelEvent
        {
            get;
            set;
        }
        private static IList<Despatch> mDespatchs = new List<Despatch>();
        private static int mDespathIndex = 0;
        internal static Despatch GetDespatch()
        {
            lock (mDespatchs)
            {
                mDespathIndex++;
                if (mDespathIndex >= mDespatchs.Count)
                    mDespathIndex = 0;
                return mDespatchs[mDespathIndex];
            }
        }
        public static Dictionary<string, int> GetDespatchStatus()
        {
            Dictionary<string, int> Result = new Dictionary<string, int>();
            for(int i =0;i<mDespatchs.Count;i++)
            {
                Result.Add(i.ToString("00"), mDespatchs[i].Count);
            }
            return Result;

        }


        public static void StopDespatch()
        {
            foreach (XmlDespatch item in mDespatchs)
            {
                item.Dispose();
            }
        }
        public static void Init(uint despaths)
        {
            StopDespatch();
            mDespatchs.Clear();
            for (int i = 0; i < despaths; i++)
            {
                mDespatchs.Add(new XmlDespatch());
            }
        }
        class XmlDespatch : Despatch
        {
            protected override void OnRun()
            {


                XmlChannel.PacketDataReaderHandler item = (XmlChannel.PacketDataReaderHandler)GetItem();
                if (item != null)
                {
                    //System.Threading.ThreadPool.QueueUserWorkItem(callAction, item);
                    callAction(item);
                }
                else
                    System.Threading.Thread.Sleep(1);

            }
            private void callAction(object data)
            {
                XmlChannel.PacketDataReaderHandler item = (XmlChannel.PacketDataReaderHandler)data;
                TcpChannel channel = item.Channel;


                try
                {
                    using (item)
                    {
                        item.Execute();
                    }
                }
                catch (Exception e_)
                {
                    channel.CallChannelError(new ChannelErrorEventArgs() { Channel = channel, Exception = e_ });
                }
            }
        }
    }
}
