﻿using System;
using System.Collections.Generic;
using System.Text;
using Smark.Net.Tcp;
namespace Smark.Net.Tcp.XmlServices
{

    public class XmlChannel:IDisposable
    {
       
        public XmlChannel(Smark.Net.Tcp.TcpChannel channel)
        {
            mChannel = channel;
            mDespatch = ServiceUtils.GetDespatch();
            OnInit();
        }
        private Despatch mDespatch;
        private XmlPacketAnalysis mPacketAnalysis;
        private Smark.Net.Tcp.TcpChannel mChannel;
        internal XmlMessageAdapter MsgAdapter = new XmlMessageAdapter();
        public Smark.Net.Tcp.TcpChannel Channel
        {
            get
            {
                return mChannel;
            }
        }
        private void OnInit()
        {
            mPacketAnalysis = new XmlPacketAnalysis(mChannel);
            mPacketAnalysis.Receive += OnPacketDataReader;
            mChannel.ChannelDisposed += OnClientDisposed;
            mChannel.DataReceive += OnDataReceive;
            mChannel.ChannelError += OnClientError;
            mChannel.BeginReceive();
        }
        private void OnPacketDataReader(PacketDataReaderArgs e)
        {
            PacketDataReaderHandler handler = new PacketDataReaderHandler();

             handler.Channel = mChannel;    
             handler.XmlChannel = this;
                handler.Item = e;
                mDespatch.Add(handler);
               
        }
        internal class XmlPacketAnalysis : PacketAnalysis<XmlMessageEof>
        {
            public XmlPacketAnalysis(TcpChannel channel) : base(channel) { }
            protected override void ExecuteReceive(DataReader dr)
            {
                try
                {

                    OnReceive(dr);
                }
                catch (Exception e_)
                {
                    Channel.CallChannelError(new ChannelErrorEventArgs() { Exception = e_, Channel = Channel });
                }
            }
        }
    
       internal  class PacketDataReaderHandler :IWorkItem
        {
            public PacketDataReaderArgs Item
            {
                get;
                set;
            }
            public TcpChannel Channel
            {
                get;
                set;
            }
            public XmlChannel XmlChannel
            {
                get;
                set;
            }
            #region IWorkItem 成员

            public TcpSocketAsyncEventArgs SocketAsyncEventArgs
            {
                get;
                set;
            }

            public void Execute()
            {

                XmlMessageAdapter adapter = XmlChannel.MsgAdapter;
                adapter.Load(Item.Channel.Coding, Item.Reader.Buffer);
                PacketInfo pi = new PacketInfo() { Channel = XmlChannel, Headers = adapter.Headers };
                try
                {
                    ServiceUtils.ChannelEvent.Process(adapter.Message, pi);
                }
                catch (Exception e_)
                {
                    Channel.CallChannelError(new ChannelErrorEventArgs() { Exception = XmlServiceException.ActionProcessError(adapter.Message.GetType(), e_) , Channel= Channel});
                   
                }
                finally
                {
                    ServiceUtils.Execute(adapter, XmlChannel, pi);
                }
            }

            #endregion

            #region IDisposable 成员

            public void Dispose()
            {
                if (Item != null)
                    Item.Reader.Buffer.Dispose();
            }

            #endregion


            TcpChannel IWorkItem.Channel
            {
                get;
                set;
            }
        }
        private void OnDataReceive(object sender, DataReceiveEventArgs e)
        {
           
            mPacketAnalysis.Import(e.Buffer);
        }
        private void OnClientError(object sender, ChannelErrorEventArgs e)
        {
            ServiceUtils.ChannelEvent.Error(e.Exception, this);
        }
        private void OnClientDisposed(object sender, ChannelEventArgs e)
        {
            if (mPacketAnalysis != null)
                mPacketAnalysis.Dispose();
            ServiceUtils.ChannelEvent.ClientDisposed(this);
        }
        public void Send(string action, string xmlbody)
        {
            Send(action, xmlbody, null);
        }
        public void Send(string action, string xmlbody,params Header[] headers)
        {
            XmlMessageAdapter adapter = new XmlMessageAdapter();
            XmlString xs = new XmlString() { Body = xmlbody };
            adapter.Action = action;
            adapter.Message = xs;
            AddHeaders(adapter, headers);
            Channel.Send(adapter);   

        }
        private void AddHeaders(XmlMessageAdapter adapter, params Header[] headers)
        {
            if (headers != null)
                foreach (Header item in headers)
                    adapter.Headers.Add(item);
        }
        public void Send(IXmlMessage message)
        {
            Send(message, null);
        }
        public void Send(IXmlMessage message, params Header[] headers)
        {
            XmlMessageAdapter adapter = new XmlMessageAdapter();
            adapter.Message = message;
            AddHeaders(adapter, headers);
            Channel.Send(adapter);
        }
        private bool mDispose = false;
        public void Dispose()
        {
            lock (this)
            {
                if (!mDispose)
                {
                    mDispose = true;
                    mPacketAnalysis = null;
                    mDespatch = null;
                    Channel.Dispose();
                }
            }
        }
    }
}
