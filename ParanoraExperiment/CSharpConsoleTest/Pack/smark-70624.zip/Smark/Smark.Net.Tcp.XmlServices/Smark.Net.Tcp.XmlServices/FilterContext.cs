﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.XmlServices
{
    public class ActionContext:IDisposable
    {
        internal ActionContext()
        {
           
        }
        internal void SetInfo(PacketInfo packetinfo, IXmlMessage msg, IList<Filter> filters, object controller, System.Reflection.MethodInfo method)
        {
            PacketInfo = packetinfo;
            Message = msg;
            Filters = filters;
            Method = method;
            Controller = controller;
            mFilterIndex = 0;
        }
        private int mFilterIndex = 0;
        internal object Controller
        {
            get;
            set;
        }
        internal Smark.Core.MethodHandler MethodHandler
        {
            get;
            set;
        }
        internal System.Reflection.MethodInfo Method
        {
            get;
            set;
        }      
        internal IList<Filter> Filters
        {
            get;
            set;
        }
        public PacketInfo PacketInfo
        {
             get;
            internal set;

        }
        public IXmlMessage Message
        {
            get;
            internal set;

        }
        public void Execute()
        {
            if (Filters.Count > 0 && mFilterIndex < Filters.Count)
            {
                mFilterIndex++;
                Filters[mFilterIndex-1].Execute(this);
                
            }
            else
            {
                if (Controller != null && Method != null)
                {
                    MethodHandler.Execute(Controller, new object[] { Message, PacketInfo });
                   
                }
            }
        }
        internal ActionContextFactory Factory
        {
            get;
            set;
        }
        #region IDisposable 成员

        public void Dispose()
        {
            if (Factory != null)
            {
                Factory.Push(this);
                Factory = null;
            }
        }

        #endregion
    }
    class ActionContextFactory
    {
        public ActionContextFactory()
        {
            for (int i = 0; i < 100; i++)
            {
                mQueue.Enqueue(new ActionContext());
            }
        }
        private Queue<ActionContext> mQueue = new Queue<ActionContext>();
        public Type ActionType
        {
            get;
            set;
        }
        public string ActionName
        {
            get;
            set;
        }
        public ActionContext Builder(XmlMessageAdapter msgadapter,XmlChannel channel,PacketInfo packetinfo)
        {
            ActionContext ac = Pop();
            if (ac == null)
            {
                ac = new ActionContext();
            }
            ac.SetInfo(packetinfo, msgadapter.Message, Filters, Controller, Method);
            ac.MethodHandler = MethodHandler;
            ac.Factory = this;
             return ac;
        
        }
        private IList<Filter> mFilters = new List<Filter>();
        public IList<Filter> Filters
        {
            internal set
            {
                mFilters = value;
            }
            get
            {
                return mFilters;
            }
            
        }
        public object Controller
        {
            get;
            set;
        }
        internal Smark.Core.MethodHandler MethodHandler
        {
            get;
            set;
        }
        public System.Reflection.MethodInfo Method
        {
            get;
            set;
        }
        public MessageConversion Conversion
        {
            get;
            set;
        }
        public  ActionContext Pop()
        {
            lock (this)
            {
                if (mQueue.Count > 0)
                    return mQueue.Dequeue();
                return null;
            }
        }
        public void Push(ActionContext ac)
        {
            lock (this)
            {
                mQueue.Enqueue(ac);
            }
        }
    }
}
