﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using Smark.Net.Tcp;
namespace Smark.Net.Tcp.XmlServices
{
    public class XmlMessageAdapter : IMessage
    {
        public string Action
        {
            get;
            set;
        }
        private IList<Header> mHeaders = new List<Header>();
        public IList<Header> Headers
        {
            get
            {
                return mHeaders;
            }
        }
        public IXmlMessage Message
        {
            get;
            set;
        }
        internal ActionContextFactory ContextFactory
        {
            get;
            set;
        }
        #region IMessage 成员

        public void Save(Encoding Coding, DataBuffer writer)
        {
            Type msgtype = Message.GetType();
            ContextFactory = ServiceUtils.GetActionContextFactory(msgtype);
            if (ContextFactory == null)
            {
                throw XmlServiceException.ActionNotFound(msgtype);
            }
            Action = ContextFactory.ActionName; //msgtype.FullName+","+msgtype.Assembly.GetName().Name;
            System.IO.MemoryStream ms = new System.IO.MemoryStream(writer.Data);
            ms.Position = 0;
            using (XmlTextWriter xmlwriter = new XmlTextWriter(ms, Coding))
            {
                xmlwriter.WriteStartElement("xml-message");
                xmlwriter.WriteStartElement("headers");
                xmlwriter.WriteStartElement("action");
                xmlwriter.WriteValue(Action);
                xmlwriter.WriteEndElement();
                foreach (Header item in Headers)
                {
                    xmlwriter.WriteStartElement(item.Name);
                    xmlwriter.WriteValue(item.Value);
                    xmlwriter.WriteEndElement();
                }
                xmlwriter.WriteEndElement();

             
                xmlwriter.WriteStartElement("body");
                ContextFactory.Conversion.ToXML(xmlwriter, Message);

                //ContextFactory.Conversion.ToXML(xmlwriter, doc);
                xmlwriter.WriteEndElement();
                xmlwriter.WriteEndElement();
                xmlwriter.Flush();
                writer.SetCount(Convert.ToInt32(ms.Position));
            }
            mLength = writer.Count;
        }

        public void Load(Encoding Coding, DataBuffer reader)
        {
            mLength = reader.Count;
            System.IO.MemoryStream ms = new System.IO.MemoryStream(reader.Data, 0, reader.Count);
            ms.Position = 0;
            System.IO.TextReader tr = new System.IO.StreamReader(ms, Coding);
            bool readheader = false;
            string type=null;
        
            using (XmlTextReader xmlr = new XmlTextReader(tr))
            {

                while (xmlr.Read())
                {
                    if (readheader)
                    {
                        if (xmlr.NodeType == XmlNodeType.Element)
                        {
                            if (xmlr.Name == "action")
                            {
                                type = xmlr.ReadString();
                                ContextFactory = ServiceUtils.GetActionContextFactory(type);
                                if (ContextFactory == null)
                                    throw XmlServiceException.ActionNotFound(type);
                                Message = (IXmlMessage)Activator.CreateInstance(ContextFactory.ActionType);
                            }
                            else
                            {
                                Headers.Add(new Header() { Name = xmlr.Name, Value = xmlr.ReadString() });
                            }
                        }
                        else
                        {
                            if (xmlr.Name == "headers" && xmlr.NodeType == XmlNodeType.EndElement)
                            {
                                readheader = false;
                            }
                        }
                    }
                    else
                    {
                        if (xmlr.Name == "headers" && xmlr.NodeType == XmlNodeType.Element)
                        {
                            readheader = true;
                        }
                        if (xmlr.Name == "body" && xmlr.NodeType == XmlNodeType.Element)
                        {

                            if (ContextFactory == null)
                            {
                                throw XmlServiceException.ActionNotFound(type);
                            }

                            if (Message != null)
                                ContextFactory.Conversion.ToObject(xmlr, Message);

                            
                            break;
                        }
                    }
                }
            }    
        }

        #endregion


        private int mLength;
        public int Length
        {
            get { return mLength; }
        }
    }
    public interface  IXmlMessage
    {

       
        #region IMessage 成员

          void SaveData(XmlTextWriter  writer);

          void LoadData(XmlTextReader reader);


        #endregion
    }
    class XmlString : IXmlMessage
    {
       
        public string Body
        {
            get;
            set;
        }


        #region IXmlMessage 成员

        public void SaveData(XmlTextWriter writer)
        {
            writer.WriteString(Body);
        }

        public void LoadData(XmlTextReader reader)
        {

            Body = reader.ReadOuterXml();
        }

        #endregion
    }
}
