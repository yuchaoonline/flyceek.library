﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.XmlServices
{
    public class PacketInfo
    {
        public XmlChannel Channel
        {
            get;
            internal set;
        }
        public IList<Header> Headers
        {
             get;
            internal set;
        }
    }
}
