﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
namespace Smark.Net.Tcp
{
   public interface IWorkItem:IDisposable
    {
       TcpSocketAsyncEventArgs SocketAsyncEventArgs
       {
           get;
           set;
        }
       TcpChannel Channel
       {
           get;
           set;
       }
        void Execute();
    }
    abstract class WorkItem : IWorkItem
    {
        #region IWorkItem Members

        public abstract void Execute();
        public TcpSocketAsyncEventArgs SocketAsyncEventArgs
        {
            get;
            set;
        }
        public TcpChannel Channel
        {
            get;
            set;
        }
        #endregion

        #region IDisposable Members

        public abstract void Dispose();
        

        #endregion
    }
  

    class ReceiveWorkItem : WorkItem
    {


        public override void Execute()
        {
            TcpChannel channel = Channel;
            DataBuffer db = channel.ReceiveBuffer;

            try
            {

                db.SetBuffer(SocketAsyncEventArgs.Buffer, SocketAsyncEventArgs.BytesTransferred);
                channel.CallDataReceive(new DataReceiveEventArgs() { Buffer = db, Channel = channel });
            }
            catch (Exception e_)
            {
                channel.CallChannelError(new ChannelErrorEventArgs() { Channel = channel, Exception = e_ });
            }
            finally
            {
               
                SocketAsyncEventArgs.Enter();
               
            }
        }

        public override void Dispose()
        {
           // SocketAsyncEventArgs.Enter();
        }
    }

}
