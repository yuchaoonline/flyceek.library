﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public interface IIPFiler
    {
        bool Execute(System.Net.IPEndPoint poing);
        
    }
}
