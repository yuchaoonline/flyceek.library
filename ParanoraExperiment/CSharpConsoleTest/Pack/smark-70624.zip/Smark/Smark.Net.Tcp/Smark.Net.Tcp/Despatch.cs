﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
namespace Smark.Net.Tcp
{
    public class Despatch:IDisposable
    {
        public Despatch()
        {
            System.Threading.Thread thread = new System.Threading.Thread(
                new System.Threading.ThreadStart(Run));
            thread.Start();
        }
     
        private Queue<IWorkItem> mQueues = new Queue<IWorkItem>(1024);
        public void Add(IWorkItem item)
        {
            lock (mQueues)
            {
                mQueues.Enqueue(item);
            }
        }
        public int Count
        {
            get
            {
                return mQueues.Count;
            }
        }
        protected IWorkItem GetItem()
        {
            lock (mQueues)
            {
                if (mQueues.Count > 0)
                    return mQueues.Dequeue();
                return null;
            }
        }
        protected virtual void OnRun()
        {
            IWorkItem item = GetItem();
            if (item != null)
            {
              
                
                try
                {
                    using (item)
                    {
                        item.Execute();
                    }
                }
                catch (Exception e_)
                {
                    if(item.Channel!=null)
                        item.Channel.CallChannelError(new ChannelErrorEventArgs() { Channel = item.Channel, Exception = e_ });
                }
            }
            else
                System.Threading.Thread.Sleep(2);
        }
        
        public virtual void Run()
        {
            
            while (!mDispose)
            {
                OnRun();
            }
        }
        private bool mDispose = false;
        public void Dispose()
        {
            lock (this)
            {
                if (!mDispose)
                {
                    mDispose = true;
                }
            }
        }
    }
}
