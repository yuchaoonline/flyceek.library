﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public interface IMessage
    {
        void Save(Encoding Coding, DataBuffer writer);
        void Load(Encoding Coding, DataBuffer reader);
        int Length { get; }
    }

}
