﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class NetTcpException:Exception
    {
        public NetTcpException()
        {
        }
        public NetTcpException(string msg)
            : base(msg)
        {
        }
        public int ErrorNumber
        {
            internal get;
            set;
        }
        
        public NetTcpException(Exception innererr, string msg) : base(msg, innererr) { }
        public const string MSG_DATA_OVERFLOW = "数据缓冲过小,写入数据错误!";
        public const string MSG_READ_DATA_ERROR = "获取数据越界!";
        public const string MSG_ERROR_IPADDRESS = "IP地址错误!";
        public const int NetTcpError_DataOverflow = 10001;
        public const int NetTcpError_ReadDataError = 10004;
        public const int NetTcpError_IpAddress = 10006;
        public static NetTcpException DataOverflow()
        {
            NetTcpException error = new NetTcpException(MSG_DATA_OVERFLOW);
            error.ErrorNumber = NetTcpError_DataOverflow;
            return error;
        }
        public static NetTcpException ReadDataError()
        {
            NetTcpException error = new NetTcpException(MSG_READ_DATA_ERROR);
            error.ErrorNumber = NetTcpError_ReadDataError;
            return error;
        }
        public static NetTcpException IPAddressError()
        {
            NetTcpException error = new NetTcpException(MSG_ERROR_IPADDRESS);
            error.ErrorNumber = NetTcpError_IpAddress;
            return error;
        }
    }
   
   
}
