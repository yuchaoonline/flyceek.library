﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
namespace Smark.Net.Tcp
{
    public class TcpChannel:IDisposable
    {

        private Core.KeyValueCollection<object> mProperties = new Core.KeyValueCollection<object>();
        public object this[string name]
        {
            get
            {
                return mProperties[name];
            }
            set
            {
                 mProperties[name] = value;
            }
        }
        public object Tag { get; set; }

    
        public event EventDataReceive DataReceive;
        public event EventChannelError ChannelError;
        public event EventChannelDisposed ChannelDisposed;
        public event EventChannelSendCompleted SendCompleted;
        public TcpChannel(Socket socket)
        {
            Coding = Encoding.UTF8;
            mSocket = socket;
            ReceiveAsyncEventArgsPool = TcpUtils.PopEventArgsPool();
            ReceiveDespatch = TcpUtils.GetReceiveDespatch();
            ClientID = Guid.NewGuid().ToString("N");
            EndPoint = (IPEndPoint)socket.RemoteEndPoint;
            SendAsyncEventArgs = new TcpSocketAsyncEventArgs(TcpUtils.DataPacketLength);
            SendAsyncEventArgs.Channel = this;
            SendQueue.Channel = this;
            SendQueue.UTK = new SendUserToken();
            SendAsyncEventArgs.UserToken = SendQueue.UTK;
        }
        internal SendQueue SendQueue = new SendQueue();
        internal TcpSocketAsyncEventArgsPool ReceiveAsyncEventArgsPool;
        internal Despatch ReceiveDespatch;
        internal TcpSocketAsyncEventArgs SendAsyncEventArgs;
        internal DataBuffer ReceiveBuffer = new DataBuffer();
        private Socket mSocket;
        public Socket Socket
        {
            get
            {
                return mSocket;
            }
        }
        public void Send(IMessage message)
        {
            
            try
            {


                SendQueue.Add(message);
                SendQueue.Send(SendAsyncEventArgs);
            }
            catch (Exception e_)
            {
               
                CallChannelError(new ChannelErrorEventArgs() { Channel = this, Exception = e_ });
            }
           

        }
        public void BeginReceive()
        {

            OnBeginReceive(null);
            //System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(OnBeginReceive), null);
        }
        private void OnBeginReceive(object obj)
        {
            if (!mIsDisposed)
            {
                TcpSocketAsyncEventArgs eventargs = ReceiveAsyncEventArgsPool.Pop();
                eventargs.Channel = this;
                try
                {

                    if (!Socket.ReceiveAsync(eventargs))//同步接收完成
                    {

                        eventargs.IO_ReceiveComplete(eventargs);
                    }
                }
                catch (Exception e_)
                {
                    eventargs.Enter();
                    CallChannelError(new ChannelErrorEventArgs() { Channel = this, Exception = e_ });
                }


            }
        }
        internal  void CallDataReceive(DataReceiveEventArgs e)
        {
            OnDataReceive(e);
        }
        internal void SendDataBuffer(SendUserToken state, TcpSocketAsyncEventArgs e)
        {
            
            try
            {
                int senddatas =state.TotalBytes - state.SendBytes;
                e.SetBuffer(state.SendBytes, senddatas);
                if (!state.Socket.SendAsync(e))//同步发送完成
                {
                    e.IO_SendComplete(e);

                }
               
                
            }
            catch (Exception e_)
            {

               
                CallChannelError(new ChannelErrorEventArgs() { Channel = this, Exception= e_ });
                SendQueue.Reset();
                SendQueue.Send(e);
            }
            
        }
        protected virtual void OnDataReceive(DataReceiveEventArgs e)
        {
            if (DataReceive != null)
                DataReceive(this, e);
        }
        internal void OnSendCompleted(ChannelSendCompletedArgs e)
        {
            e.Channel = this;
            if (SendCompleted != null)
            {
                //System.Threading.ThreadPool.QueueUserWorkItem(OnSendCompletedExecute, e);
                OnSendCompletedExecute(e);
            }
        }
        private void OnSendCompletedExecute(object data)
        {
            ChannelSendCompletedArgs e = (ChannelSendCompletedArgs)data;
            try
            {
                
                 SendCompleted(this, e);
               
            }
            catch (Exception e_)
            {
                ChannelErrorEventArgs err = new ChannelErrorEventArgs();
                err.Channel = this;
                err.Exception = e_;
                CallChannelError(err);
            }
        }
        public void CallChannelError(ChannelErrorEventArgs e)
        {
            
            System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(OnChannelError), e);
        }
        protected virtual void OnChannelError(object e)
        {
            ChannelErrorEventArgs args = (ChannelErrorEventArgs)e;
            if (ChannelError != null)
            {

                if (args.Exception is SocketException || args.Exception is ObjectDisposedException)
                        Dispose();
                ChannelError(this, args);
                
            }

        }
        protected virtual void OnChannelDisposed(ChannelEventArgs e)
        {
            if (ChannelDisposed != null)
                ChannelDisposed(this, e);
        }
        public Encoding Coding
        {
            get;
            set;
        }
        public string ClientID
        {
            get;
            internal set;
        }
        public TcpServer Server
        {
            get;
            internal set;
        }
        public IPEndPoint EndPoint
        {
            get;
            internal set;
        }
        public string Name
        {
            get;
            set;

        }
       
        #region IDisposable Members
        private bool mIsDisposed = false;
        public void Dispose()
        {
            lock (this)
            {
                if (!mIsDisposed)
                {
                    mIsDisposed = true;
                    try
                    {
                        mSocket.Shutdown(SocketShutdown.Both);
                        mSocket.Close();
                    }
                    catch 
                    {

                    }
                    finally
                    {
                        SendAsyncEventArgs = null;
                        Tag = null;
                        SendQueue.Clear();
                        TcpUtils.PushEventArgsPool(ReceiveAsyncEventArgsPool);
                        OnChannelDisposed(new ChannelEventArgs() { Channel = this });


                    }
                }
            }
        }

        #endregion
    }
}
