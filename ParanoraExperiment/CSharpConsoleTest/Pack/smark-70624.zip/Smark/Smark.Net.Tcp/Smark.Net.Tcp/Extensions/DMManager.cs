﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.Extensions
{
    public class DMManager:IDisposable
    {
        
        public DMManager(int despatchs)
        {
            for (int i = 0; i < despatchs; i++)
            {
                mDespatch.Add(new Despatch());
            }
        }
        public EventDataMessageReceive DataMessageReceive;
        private int mCurIndex=0;
        private IList<Despatch> mDespatch = new List<Despatch>();
        private Despatch GetDespatch()
        {
            lock (mDespatch)
            {
                mCurIndex++;
                if (mCurIndex >= mDespatch.Count)
                    mCurIndex = 0;
                return mDespatch[mCurIndex];
            }
        }
        public void AddConnection(TcpChannel channel)
        {
            DMTag tag = new DMTag();
            tag.PacketAnalysis = new DMPacketAnalysis(channel);
            tag.Despatch = GetDespatch();
            channel.Tag = tag;
            tag.PacketAnalysis.Receive += ImportData;
            channel.DataReceive += dataReceive;
            
        }
        private void OnExecute(PacketDataReaderArgs e)
        {
            DataMessage datamessage = new DataMessage();
            datamessage.Load(e.Channel.Coding, e.Buffer);
        }
        private void dataReceive(object sernder, DataReceiveEventArgs e)
        {
            DMTag tag = (DMTag)e.Channel.Tag;
            tag.PacketAnalysis.Import(e.Buffer);
        }
        private void ImportData( PacketDataReaderArgs e)
        {
            DMTag tag = (DMTag)e.Channel.Tag;
            DMWorkItem work = new DMWorkItem();
            work.Channel = e.Channel;
            work.Data = e;
            work.Action = OnExecute;
            tag.Despatch.Add(work);
        }
        class DMTag
        {
            public DMPacketAnalysis PacketAnalysis;
            public Despatch Despatch;
        }
        class DMWorkItem : IWorkItem
        {
            public Action<PacketDataReaderArgs> Action;
            public TcpSocketAsyncEventArgs SocketAsyncEventArgs
            {
                get;
                set;
            }
            public TcpChannel Channel
            {
                get;
                set;
            }
            public PacketDataReaderArgs Data
            {
                get;
                set;
            }
            public void Execute()
            {
                if (Action != null)
                    Action(Data);
            }

            public void Dispose()
            {
                Data.Buffer.Dispose();
            }
        }

        private bool mDispose = false;
        public void Dispose()
        {
            lock (this)
            {
                if (!mDispose)
                {
                    foreach(Despatch item in mDespatch)
                    {
                        item.Dispose();
                    }
                    mDespatch.Clear();
                    mDispose = true;
                }
            }
           
        }
        public void Send(IDataObject data,TcpChannel channel)
        {
            DataMessage dm = new DataMessage();
            dm.Data = data;
            channel.Send(dm);
        }
    }
}
