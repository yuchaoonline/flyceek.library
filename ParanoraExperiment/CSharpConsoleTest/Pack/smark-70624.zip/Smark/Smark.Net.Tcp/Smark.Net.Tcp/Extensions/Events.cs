﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.Extensions
{
    public delegate void EventDataMessageReceive(object server,DataMessageReceiveArgs e);
    public class DataMessageReceiveArgs : EventArgs
    {
        public TcpChannel Channel
        {
            get;
            internal set;
        }
        public DMManager Manager
        {
            get;
            internal set;
        }
        public IDataObject Data
        {
            get;
            internal set;
        }
    }
}
