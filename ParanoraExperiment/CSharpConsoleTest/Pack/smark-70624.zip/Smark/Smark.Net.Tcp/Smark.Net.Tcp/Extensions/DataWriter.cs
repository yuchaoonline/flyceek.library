﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.Extensions
{
    public class DataWriter
    {
        public DataWriter(Encoding coding, DataBuffer buffer)
        {

            mBuffer = buffer;
            Coding = Encoding.ASCII;
        }
        public Encoding Coding
        {
            get;
            set;
        }
        private DataBuffer mBuffer;
        public DataBuffer Buffer
        {
            get
            {
                return mBuffer;
            }
        }
        public void Write(byte value)
        {
            Write(new byte[] { value });
        }
        public void Write(bool value)
        {
            Write(BitConverter.GetBytes(value));
        }
        public void Write(char value)
        {
            Write(BitConverter.GetBytes(value));
        }
        public void Write(double value)
        {
            Write(BitConverter.GetBytes(value));
        }
        public void Write(Int16 value)
        {
            Write(BitConverter.GetBytes(value));
        }
        public void Write(IDataObject message)
        {
            message.SaveData(this);
        }
        public void Write(IList<IDataObject> messages)
        {
            Write(messages.Count);
            foreach (IDataObject item in messages)
            {
                item.SaveData(this);
            }
        }
        public void Write(Int32 value)
        {
            Write(BitConverter.GetBytes(value));
        }
        public void Write(Int64 value)
        {
            Write(BitConverter.GetBytes(value));
        }
        public void Write(string value)
        {
            Write(Coding.GetBytes(value));
        }
        public void WriteByteBlock(byte[] value)
        {
            if (value == null || value.Length == 0)
                Write(0);
            else
            {
                Write(value.Length);
                Write(value);
            }
        }
        public void WriteBlock(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                Write(0);

            }
            else
            {
                byte[] data = Coding.GetBytes(value);
                WriteByteBlock(data);
            }
        }
        public void Write(byte[] value)
        {
            mBuffer.Write(value);

        }
    }
}
