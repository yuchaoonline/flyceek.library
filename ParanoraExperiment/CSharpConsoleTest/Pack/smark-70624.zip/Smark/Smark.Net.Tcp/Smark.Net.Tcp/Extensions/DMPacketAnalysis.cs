﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.Extensions
{
    public class DMPacketAnalysis:PacketAnalysis<HeaderSize>
    {
        public DMPacketAnalysis(Tcp.TcpChannel channel) : base(channel) { }

        protected override void ExecuteReceive(DataBuffer dr)
        {
            OnReceive(dr);
        }
    }
}
