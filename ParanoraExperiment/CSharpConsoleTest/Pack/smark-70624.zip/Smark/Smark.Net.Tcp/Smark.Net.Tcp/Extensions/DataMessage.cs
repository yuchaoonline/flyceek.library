﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.Extensions
{
    class DataMessage : IMessage
    {
        #region IMessage 成员
        const int MSG_NULL = 0;
        public void Save(Encoding Coding, DataBuffer writer)
        {
            DataWriter dw = new DataWriter(Coding, writer);
            dw.Write(MSG_NULL);
            Data.SaveData(dw);
            mLength = writer.mCount;
            BitConverter.GetBytes(mLength).CopyTo(writer.Data, 0);
        }
        public IDataObject Data
        {
            get;
            set;
        }
        
     
        public void Load(Encoding Coding, DataBuffer reader)
        {
            mLength = reader.mCount;
            DataReader dr = new DataReader(Coding, reader);
            dr.ToInt32();
            Data.LoadData(dr);
        }

        #endregion

        private int mLength = 0;
        public int Length
        {
            get { 
                return mLength; }
        }
    }
}
