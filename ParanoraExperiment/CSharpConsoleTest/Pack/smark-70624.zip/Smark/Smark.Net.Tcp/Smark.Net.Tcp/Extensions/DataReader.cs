﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.Extensions
{
    public class DataReader
    {
        public DataReader(Encoding coding, DataBuffer buffer)
        {
            mBuffer = buffer;
            mBuffer.SetPostion(0);
            Coding = Encoding.ASCII;
        }
        public Encoding Coding
        {
            get;
            set;
        }

        private DataBuffer mBuffer;
        public DataBuffer Buffer
        {
            get
            {
                return mBuffer;
            }
        }
        private int mPostion = 0;
        public bool ToBoolean()
        {
            bool result = BitConverter.ToBoolean(mBuffer.Data, mPostion);
            mPostion++;
            return result;
        }
        public char ToChar()
        {
            char result = BitConverter.ToChar(mBuffer.Data, mPostion);
            mPostion += 2;
            return result;
        }
        public double ToDouble()
        {
            double result = BitConverter.ToDouble(mBuffer.Data, mPostion);
            mPostion += 8;
            return result;
        }
        public Int16 ToInt16()
        {
            Int16 result = BitConverter.ToInt16(mBuffer.Data, mPostion);
            mPostion += 2;
            return result;
        }
        public Int32 ToInt32()
        {
            Int32 result = BitConverter.ToInt32(mBuffer.Data, mPostion);
            mPostion += 4;
            return result;
        }
        public Int64 ToInt64()
        {
            Int64 result = BitConverter.ToInt64(mBuffer.Data, mPostion);
            mPostion += 8;
            return result;
        }
        public Single ToSingle()
        {
            Single result = BitConverter.ToSingle(mBuffer.Data, mPostion);
            mPostion += 4;
            return result;
        }
        public UInt16 ToUInt16()
        {
            UInt16 result = BitConverter.ToUInt16(mBuffer.Data, mPostion);
            mPostion += 2;
            return result;
        }
        public UInt32 ToUInt32()
        {
            UInt32 result = BitConverter.ToUInt32(mBuffer.Data, mPostion);
            mPostion += 4;
            return result;
        }
        public UInt64 ToUInt64()
        {
            UInt64 result = BitConverter.ToUInt64(mBuffer.Data, mPostion);
            mPostion += 8;
            return result;
        }
        public byte[] ToBytes(int count)
        {


            byte[] result = new byte[count];
            for (int i = mPostion; i < mPostion + count; i++)
            {
                if (i >= mBuffer.Data.Length)
                    throw NetTcpException.ReadDataError();
                result[i - mPostion] = mBuffer.Data[i];
            }
            mPostion += count;
            return result;
        }
        public byte[] BlockToBytes()
        {
            int length = ToInt32();
            if (length > 0)
                return ToBytes(length);
            return new byte[0];
        }
        public string BlockToString()
        {
            int length = ToInt32();
            if (length > 0)
                return ToString(length);
            return null;
        }
        public override string ToString()
        {
            return Coding.GetString(mBuffer.Data, 0, mBuffer.Count);
        }
        public IDataObject ToMessage<T>() where T:IDataObject,new()
        {
            T item = new T();
            item.LoadData(this);
            return item;
        }
        public IList<IDataObject> ToMessages<T>() where T : IDataObject, new()
        {
            List<IDataObject> result = new List<IDataObject>();
            int lenfth = ToInt32();
            for (int i = 0; i < lenfth; i++)
            {
                T item = new T();
                item.LoadData(this);
                result.Add(item);
            }
            return result;
        }
        public string ToString(int count)
        {
            if (count + mPostion > mBuffer.Data.Length)
                throw NetTcpException.ReadDataError();
            string result = Coding.GetString(mBuffer.Data, mPostion, count);
            mPostion += count;
            return result;
        }
    }
}
