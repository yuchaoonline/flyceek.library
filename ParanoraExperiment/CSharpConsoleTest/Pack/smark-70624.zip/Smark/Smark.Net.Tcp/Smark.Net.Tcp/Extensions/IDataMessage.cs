﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp.Extensions
{
    public interface IDataObject
    {
        void SaveData(DataWriter writer);
        void LoadData(DataReader reader);
    }
}
