﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public abstract class DataMessage : IMessage
    {
        #region IMessage 成员

        public void Save(Encoding Coding, DataBuffer writer)
        {
            OnSave(new DataWriter(Coding, writer));
        }
        protected abstract void OnSave(DataWriter writer);
        protected abstract void OnLoad(DataReader reader);
        public void Load(Encoding Coding, DataBuffer reader)
        {
            OnLoad(new DataReader(Coding, reader));
        }

        #endregion
    }
}
