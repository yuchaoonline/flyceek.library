﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class TcpSocketAsyncEventArgsPool
    {
        private Queue<TcpSocketAsyncEventArgs> mQueue;
        private int mBufferLength = 1024;
        public TcpSocketAsyncEventArgsPool(int count, int bufferlength)
        {
            mBufferLength = bufferlength;
            mQueue = new Queue<TcpSocketAsyncEventArgs>(mBufferLength );
            for (int i = 0; i < count; i++)
            {
                mQueue.Enqueue(createItem());
            }
        }
        public int Count
        {
            get
            {
                return mQueue.Count;
            }
        }
        private TcpSocketAsyncEventArgs createItem()
        {
            TcpSocketAsyncEventArgs item= new TcpSocketAsyncEventArgs(mBufferLength);
            item.Pool = this;
            return item;
        }
        public TcpSocketAsyncEventArgs Pop()
        {
            lock (mQueue)
            {
                TcpSocketAsyncEventArgs result = null;
                if (mQueue.Count > 0)
                    result= mQueue.Dequeue();
                else
                    result= createItem();
                result.Reset();
                return result;
            }
        }
        public void Push(TcpSocketAsyncEventArgs item)
        {
            lock (mQueue)
            {
                mQueue.Enqueue(item);
            }
        }
    }
}
