﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public delegate void EventDataReceive(object sender, DataReceiveEventArgs e);
    public delegate void EventChannelError(object sender, ChannelErrorEventArgs e);
    public delegate void EventChannelDisposed(object sender, ChannelEventArgs e);
    public delegate void EventChannelConnected(object sender, ChannelEventArgs e);
    public delegate void EventChannelSendCompleted(object sender,ChannelSendCompletedArgs e);
}
