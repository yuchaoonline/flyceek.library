﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class ChannelEventArgs
    {
        public TcpChannel Channel
        {
            get;
            set;
        }
    }
}
