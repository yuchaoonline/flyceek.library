﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class ChannelErrorEventArgs:ChannelEventArgs
    {
        public Exception Exception
        {
            get;
            set;
        }
    }
}
