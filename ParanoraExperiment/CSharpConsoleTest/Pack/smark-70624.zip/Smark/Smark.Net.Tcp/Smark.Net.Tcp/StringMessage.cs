﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class StringMessage:IMessage
    {
        public string Value
        {
            get;
            set;
        }
        private int mLength;
        public void Save(Encoding Coding, DataBuffer writer)
        {
            writer.Write(Coding.GetBytes(Value));
            mLength = writer.Count;
        }

        public void Load(Encoding Coding, DataBuffer reader)
        {
            Value = Coding.GetString(reader.Data,0, reader.Count);
            mLength = reader.Count;
        }

        public int Length
        {
            get { return mLength; }
        }
    }
}
