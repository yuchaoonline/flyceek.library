﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class TcpUtils
    {
        static TcpUtils()
        {
           
           
            DataPacketLength = 8000;
            DataBufferPools = 1;
			Connections=1000;

        }
        private static Queue<TcpSocketAsyncEventArgsPool> mEventArgsPoolQueue = new Queue<TcpSocketAsyncEventArgsPool>();
        private static IList<DataBufferPool> mDataBufferPoolList = new List<DataBufferPool>();
        private static IList<Despatch> mReceiveDespatchList = new List<Despatch>();
        /// <summary>
        /// 数据包最大长度
        /// </summary>
        public static int DataPacketLength
        {
            get;
             set;
        }

      
        //默认配置最大支持连接数
		public static int Connections
		{
			get;
			set;
		}
        //数据缓冲池数量
        internal static int DataBufferPools
        {
            get;
            set;
        }
        private static int mReceiveDespatchIndex=0;
        internal static Despatch GetReceiveDespatch()
        {
            lock (mReceiveDespatchList)
            {
                mReceiveDespatchIndex++;
                if (mReceiveDespatchIndex >= mReceiveDespatchList.Count)
                    mReceiveDespatchIndex = 0;
                
                    
                return mReceiveDespatchList[mReceiveDespatchIndex];
            }
        }
        private static int mDataBufferPoolIndex = 0;
        internal static DataBufferPool GetDataBufferPool()
        {
            lock (mDataBufferPoolList)
            {
                mDataBufferPoolIndex++;
                if (mDataBufferPoolIndex >= mDataBufferPoolList.Count)
                    mDataBufferPoolIndex = 0;
                return mDataBufferPoolList[mDataBufferPoolIndex];
            }
        }
        internal static TcpSocketAsyncEventArgsPool PopEventArgsPool()
        {
            lock (mEventArgsPoolQueue)
            {
                if (mEventArgsPoolQueue.Count > 0)
                    return mEventArgsPoolQueue.Dequeue();
                return CreateAsyncEventArgsPool();
            }
        }
        internal static void PushEventArgsPool(TcpSocketAsyncEventArgsPool e)
        {
            lock (mEventArgsPoolQueue)
            {
                mEventArgsPoolQueue.Enqueue(e);
            }
        }
        private static TcpSocketAsyncEventArgsPool CreateAsyncEventArgsPool()
        {
            return new TcpSocketAsyncEventArgsPool(5, DataPacketLength/2); 
        }
        public static void StopDespatch()
        {
            foreach (Despatch item in mReceiveDespatchList)
            {
                item.Dispose();
            }
        }
        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="count">最大支持连接数</param>
        /// <param name="bufferpools">数据缓冲池数量，每个池默认有1000个buffer</param>
        /// <param name="despatchs">接收数据调度器数量</param>
        public static void Setup(int count, int bufferpools, int despatchs)
        {
            Connections= count;
           
            StopDespatch();
            foreach (DataBufferPool item in mDataBufferPoolList)
            {
                item.Clear();
            }
            mDataBufferPoolList.Clear();
            mEventArgsPoolQueue.Clear();
            mReceiveDespatchList.Clear();
			for (int i = 0; i < bufferpools; i++)
            {
                mDataBufferPoolList.Add(new DataBufferPool(500, DataPacketLength));
            }

            for (int i = 0; i < Connections; i++)
            {
                TcpSocketAsyncEventArgsPool eap = CreateAsyncEventArgsPool();
                mEventArgsPoolQueue.Enqueue(eap);
            }
            for (int i = 0; i < despatchs; i++)
            {
                mReceiveDespatchList.Add(new Despatch());
            }
        }
        public static void Setup(int maxonlineconnections, int despatchs)
        {

            Setup(maxonlineconnections, Convert.ToInt32(Math.Ceiling(maxonlineconnections / 1000.0)) * 2,despatchs);
        }
        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="count">最大支持连接数</param>
        public static void Setup(int maxonlineconnections)
        {

            Setup(maxonlineconnections, Convert.ToInt32(Math.Ceiling(maxonlineconnections / 1000.0)) * 2, 5);
        }
        public static int FreeSocketArgs
        {
            get
            {
                return mEventArgsPoolQueue.Count;
            }
        }
        public static Dictionary<string, int> GetDataBufferPoolStatus()
        {
            Dictionary<string, int> result = new Dictionary<string, int>();
            for (int i = 0; i < mDataBufferPoolList.Count; i++)
            {
                result.Add(i.ToString("00"), mDataBufferPoolList[i].Count);
            }
            return result;
        }
        public static Dictionary<string, int> GetDespatchStatus()
        {
            Dictionary<string, int> result = new Dictionary<string, int>();
            for (int i = 0; i < mReceiveDespatchList.Count; i++)
            {
                result.Add(i.ToString("00"), mReceiveDespatchList[i].Count);
            }
            return result;
        }
        public static StringBuilder GetInfo()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("======================Resource Status======================");
            sb.AppendFormat("    Connection Pools:{0}", mEventArgsPoolQueue.Count);
           
            sb.AppendLine("\r\n--------------------------------------------------------");
            sb.AppendLine("    DataBuffer Pools:");
            sb.Append("    ");
            for (int i = 0; i < mDataBufferPoolList.Count; i++)
            {
                if (i > 0 && (i % 5) == 0)
                    sb.Append("\r\n    ");
                sb.AppendFormat("{0:00}:{1:0000}    ", i, mDataBufferPoolList[i].Count);
            }
            sb.AppendLine("\r\n--------------------------------------------------------");

            sb.AppendLine("    Receive Despatch:");
            sb.Append("    ");
            for (int i = 0; i < mReceiveDespatchList.Count; i++)
            {
                if (i > 0 && (i % 5) == 0)
                    sb.Append("\r\n    ");
                sb.AppendFormat("{0:00}:{1:0000}    ", i, mReceiveDespatchList[i].Count);
            }
            sb.AppendLine("\r\n========================================================");
            sb.Append("");
            return sb;
        }
    }
}
