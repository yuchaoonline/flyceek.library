﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class DataReceiveEventArgs:ChannelEventArgs
    {
        public DataBuffer Buffer
        {
             get;
            internal set;
        }
    }
}
