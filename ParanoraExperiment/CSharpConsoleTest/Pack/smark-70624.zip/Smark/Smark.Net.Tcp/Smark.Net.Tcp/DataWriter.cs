﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class DataWriter
    {
        public DataWriter(Encoding coding, DataBuffer buffer)
        {

            mBuffer = buffer;
            Coding = Encoding.ASCII;
        }
        public Encoding Coding
        {
            get;
            set;
        }
        private DataBuffer mBuffer;
        public DataBuffer Buffer
        {
            get
            {
                return mBuffer;
            }
        }
        public void Write(byte value)
        {
            Write(new byte[] { value });
        }
        public void Write(bool value)
        {
            Write(BitConverter.GetBytes(value));
        }
        public void Write(char value)
        {
            Write(BitConverter.GetBytes(value));
        }
        public void Write(double value)
        {
            Write(BitConverter.GetBytes(value));
        }
        public void Write(Int16 value)
        {
            Write(BitConverter.GetBytes(value));
        }
        public void Write(Int32 value)
        {
            Write(BitConverter.GetBytes(value));
        }
        public void Write(Int64 value)
        {
            Write(BitConverter.GetBytes(value));
        }
        public void Write(string value)
        {
            Write(Coding.GetBytes(value));
        }
        public void WriteBlock(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                Write(0);

            }
            else
            {
                byte[] data = Coding.GetBytes(value);
                Write(data.Length);
                Write(data);
            }
        }
        public void Write(byte[] value)
        {
            mBuffer.Write(value);

        }
    }
}
