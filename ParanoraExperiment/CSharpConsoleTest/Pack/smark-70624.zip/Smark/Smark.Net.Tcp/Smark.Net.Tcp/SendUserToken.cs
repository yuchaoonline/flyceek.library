﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    class SendUserToken
    {
        /// <summary>
        /// 需要发送字节的总数
        /// </summary>
        public int TotalBytes
        {
            get;
            set;
        }
        public int SendBytes
        {
            get;
            set;

        }
        public IMessage Message
        {
            get;
            set;
        }
        public System.Net.Sockets.Socket Socket
        {
            get;
            set;
        }
        
    }
}
