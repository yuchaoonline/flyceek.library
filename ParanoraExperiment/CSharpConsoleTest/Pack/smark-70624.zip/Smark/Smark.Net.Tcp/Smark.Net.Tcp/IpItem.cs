﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
namespace Smark.Net.Tcp
{
    public class IpItem
    {


        public IpItem(IPAddress ip)
        {
            mValue1 = ip.GetAddressBytes();
        }
        public IpItem(IPAddress startip, IPAddress endip)
        {
            mValue1 = startip.GetAddressBytes();
            mValue2 = endip.GetAddressBytes();
            mIsRegion = true;
        }
        public IpItem(IPAddress startip, IPAddress endip, bool not)
        {
            mValue1 = startip.GetAddressBytes();
            mValue2 = endip.GetAddressBytes();
            mIsRegion = true;
            mNot = true;
        }
        private bool mNot = false;
        private bool mIsRegion = false;
        private byte[] mValue1;
        private byte[] mValue2;
        public override bool Equals(object obj)
        {
            IPAddress ip = obj as IPAddress;
            bool result = false;
            if ((ip == null))
                return result;


            byte[] ipvalues = ip.GetAddressBytes();
            if (mIsRegion)
            {
                result= ipvalues[0] >= mValue1[0] && ipvalues[0] <= mValue2[0]
                    & ipvalues[1] >= mValue1[1] && ipvalues[0] <= mValue2[1]
                    & ipvalues[2] >= mValue1[2] && ipvalues[0] <= mValue2[2]
                     & ipvalues[3] >= mValue1[3] && ipvalues[0] <= mValue2[3];
            }
            else
            {
                result= ipvalues[0] == mValue1[0]
                    & ipvalues[1] == mValue1[1]
                    & ipvalues[2] == mValue1[2]
                    & ipvalues[3] == mValue1[3];
            }
            return result & !mNot;
        }
  
       
    }
}
