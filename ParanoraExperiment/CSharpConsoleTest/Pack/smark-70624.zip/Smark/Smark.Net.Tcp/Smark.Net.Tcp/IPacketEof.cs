﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public interface IPacketEof
    {
        bool Eof(DataBuffer rb, DataBuffer e, byte[] eofdata);
        byte[] EofData { get; }
        Encoding Coding { get; set; }
    }
    public class HeaderSize : IPacketEof
    {

        #region IPacketEof 成员


        private int PageSize = 0;
        public bool Eof(DataBuffer rb, DataBuffer e, byte[] eofdata)
        {
            if (rb.mCount > 4 && PageSize == 0)
                PageSize = BitConverter.ToInt32(rb.Data, 0);
            if (PageSize > 0 && PageSize == rb.mCount)
            {
                PageSize = 0;
                return true;
            }
            return false;
        }

        public byte[] EofData
        {
            get { return new byte[0]; }
        }

        #endregion

        #region IPacketEof 成员


        public Encoding Coding
        {
            get;
            set;
        }

        #endregion
    }
    public abstract class EofAdapter : IPacketEof
    {

        #region IPacketEof 成员
        private int mPostion = 0;


        public bool Eof(DataBuffer rb, DataBuffer e, byte[] eofdata)
        {


            bool result = false;
            if (rb.Count < eofdata.Length)
                return result;

            if (rb.Data[rb.mCount - 1] == eofdata[mPostion])
            {
                if (mPostion == eofdata.Length - 1)
                {
                    mPostion = 0;
                    result = true;
                }
                else
                {
                    mPostion++;
                }
            }
            else
            {
                mPostion = 0;
            }
            return result;
        }

        public abstract byte[] EofData
        {
            get;
        }

        #endregion
        public Encoding Coding
        {
            get;
            set;
        }
    }
    public class EofAtEnter : EofAdapter
    {
        public EofAtEnter()
        {
            
        }
        private byte[] mEofData=null;

        public override byte[] EofData
        {
            get {
                if (mEofData == null)
                    mEofData = Coding.GetBytes("\n");
                return mEofData; 
            
            }
        }



    }

}
