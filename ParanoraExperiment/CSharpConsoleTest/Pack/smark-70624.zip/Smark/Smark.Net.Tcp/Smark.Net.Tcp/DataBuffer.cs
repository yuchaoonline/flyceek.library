﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class DataBuffer:IDisposable
    {
        public DataBuffer(int count)
        {
            Data = new byte[count];
            mStream = new System.IO.MemoryStream(Data);
        }
        private System.IO.MemoryStream mStream;
        public System.IO.MemoryStream Stream
        {
            get
            {
                mStream.Position = 0;
                mStream.SetLength(mCount);
                return mStream;
            }
        }
        public DataBuffer()
        {

        }
        internal void SetBuffer(byte[] data, int count)
        {
            mPostion = 0;
            Data = data;
            mCount = count;
        }
        public DataBuffer(byte[] data)
        {
            Data = data;
            
        }
        public void Write(byte[] data, int count)
        {
            for (int i = 0; i < count; i++)
            {
                Write(data[0]);
            }
        }
        internal int mCount = 0;
        public int Count
        {
            get
            {
                return mCount;
            }
        }
        private int mPostion = 0;
        public int Postion
        {
            get
            {
                return mPostion;
            }
        }
        public byte[] Data;
        public void Write(byte data)
        {
            mCount++;
            if (mCount > Data.Length)
                NetTcpException.DataOverflow();
            Data[mPostion] = data;
            mPostion++;

          
        }
        public byte[] GetBytes()
        {
            byte[] result = new byte[mCount];
            for (int i = 0; i < mCount; i++)
            {
                result[i] = Data[i];
            }
            return result;
        }
        public void Write(byte[] data)
        {
            if (data == null || data.Length == 0)
                return;
            mCount += data.Length;
            if (mCount > Data.Length)
                NetTcpException.DataOverflow();
            data.CopyTo(Data, mPostion);
            mPostion += data.Length;



        }
        public void WriteStream(System.IO.Stream stream)
        {
            int length = Convert.ToInt32(stream.Length);
            if (stream.Length > (Data.Length - Count))
                NetTcpException.DataOverflow();
            stream.Read(Data, Count, length);
            mCount += length;

        }
        internal void SetPostion(int value)
        {
            mPostion = value;
        }
        public void SetCount(int value)
        {
            mCount = value;
        }
        public DataBufferPool Pool
        {
            get;
            set;
        }
        public void Reset()
        {
            SetPostion(0);
            SetCount(0);
        }
        #region IDisposable 成员
        public void Dispose()
        {

            
            Reset();
            if (Pool != null)
                Pool.Push(this);

        }
        #endregion
    }
}
