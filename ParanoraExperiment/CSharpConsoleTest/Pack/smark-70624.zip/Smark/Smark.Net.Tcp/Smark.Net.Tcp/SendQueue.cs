﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    internal class SendQueue
    {
        public SendQueue()
        {
            Status = false;
        }
        private Queue<IMessage> mMessages = new Queue<IMessage>(100);
        public void Clear()
        {
            mMessages.Clear();
        }
        private DataBuffer mDataBuffer = new DataBuffer();
        public bool Status
        {
            get;
            set;
        }
        public void Add(IMessage msg)
        {
            lock (this)
            {
                mMessages.Enqueue(msg);
            }
        }
        public TcpChannel Channel
        {
            get;
            set;
        }
        public SendUserToken UTK
        {
            get;
            set;
        }
        public void Send(TcpSocketAsyncEventArgs e)
        {
            IMessage message = null;
            
            lock (this)
            {
                if (!Status && mMessages.Count >0)
                {
                    Status = true;
                    message = mMessages.Dequeue();
                   
                    
                }
            }
            if (message != null)
            {

               
                try
                {
                    mDataBuffer.SetBuffer(e.Buffer, 0);
                    message.Save(Channel.Coding, mDataBuffer);
                    UTK.TotalBytes = mDataBuffer.mCount;
                }
                catch (Exception e_)
                {

                    Channel.CallChannelError(new ChannelErrorEventArgs() { Channel = Channel, Exception = e_ });
                    Reset();
                    Send(e);
                    return;
                }
                UTK.Message = message;
                UTK.SendBytes = 0;
                UTK.Socket = Channel.Socket;
                Channel.SendDataBuffer(UTK, e);
            }
        }
        public void Reset()
        {
            Status = false;
        }
    }
}
