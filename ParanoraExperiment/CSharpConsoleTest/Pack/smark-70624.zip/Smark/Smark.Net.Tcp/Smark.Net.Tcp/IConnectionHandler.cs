using System;
using System.Net.Sockets;
namespace Smark.Net.Tcp
{
	public interface IConnectionHandler
	{
		bool Connecting(Socket socket,TcpServer server);
	}
}

