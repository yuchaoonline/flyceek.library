﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class DataBufferPool
    {
        private Queue<DataBuffer> mQueue; 
        public DataBufferPool(int count, int bufferlength)
        {
            mBufferLength = bufferlength;
            mQueue = new Queue<DataBuffer>(count * 2);
            for (int i = 0; i < count; i++)
            {
                mQueue.Enqueue(create());
            }
               
        }

        public DataBufferPool(int count)
        {
            mBufferLength = -1;
            mQueue = new Queue<DataBuffer>(count * 2);
            for (int i = 0; i < count; i++)
            {
                mQueue.Enqueue(create());
            }
        }
        public int Count
        {
            get
            {
                return mQueue.Count;
            }
        }
        private int mBufferLength = 0;
        private DataBuffer create()
        {
            DataBuffer db;
            if (mBufferLength > 0)
                db = new DataBuffer(mBufferLength);
            else
                db = new DataBuffer();

            db.Pool = this;
            return db;
        }
        public DataBuffer Pop()
        {
            lock (mQueue)
            {
                DataBuffer result;
                if (mQueue.Count > 0)
                    result = mQueue.Dequeue();
                else
                    result = create();
                result.Reset();
                return result;

            }
        }
        public void Push(DataBuffer item)
        {
            lock (mQueue)
            {
                mQueue.Enqueue(item);
            }
        }
        public void Clear()
        {
            while (mQueue.Count > 0)
            {
                DataBuffer db = mQueue.Dequeue();
                db.Pool = null;
            }
        }
    }
}
