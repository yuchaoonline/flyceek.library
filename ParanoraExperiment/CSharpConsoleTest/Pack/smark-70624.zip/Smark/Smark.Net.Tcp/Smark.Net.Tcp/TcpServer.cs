﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
namespace Smark.Net.Tcp
{
    public class TcpServer : IDisposable
    {
        public TcpServer()
        {
            Coding = Encoding.ASCII;
            mClients = new List<TcpChannel>(TcpUtils.Connections);
        }
        #region property
        private Dictionary<Type, IIPFiler> mFilters = new Dictionary<Type, IIPFiler>();
            
        private System.Threading.ManualResetEvent allDone = new ManualResetEvent(false);
        private bool IsRun = true;
        private IList<TcpChannel> mClients = null;
        private IPEndPoint mPoint;
        public event EventChannelConnected ChannelConnected;
        public event EventChannelDisposed ChannelDisposed;
        private Socket mSocket;
        public Socket Socket
        {
            get
            {
                return mSocket;
            }
        }
        public void SetFilter<T>() where T : IIPFiler,new()
        {
            lock (mFilters)
            {
                mFilters[typeof(T)] = new T();
            }
        }
        public T GetFilter<T>() where T : IIPFiler, new()
        {
            lock (mFilters)
            {
                Type key = typeof(T);
                if (!mFilters.ContainsKey(key))
                    mFilters.Add(key, new T());
                return (T)mFilters[key];
            }
        }
        public IList<TcpChannel> Clients
        {
            get
            {
                return mClients;
            }
        }
        public Encoding Coding
        {
            get;
            set;
        }
        #endregion
		
		
        
        #region method
        private object mLockOnlineChange = new object();
 
        public IList<TcpChannel> GetOnlines()
        {
            lock (mLockOnlineChange)
            {
                IList<TcpChannel> result = new List<TcpChannel>();
                foreach (TcpChannel item in Clients)
                {
                    result.Add(item);
                }
                return result;
            }
        }
        private void AddOnline(TcpChannel e)
        {
            lock (mLockOnlineChange)
            {
                Clients.Add(e);
            }
        }
        public TcpChannel FindClient(string id, string name)
        {
            foreach (TcpChannel item in GetOnlines())
            {
                if (id == item.ClientID || (!string.IsNullOrEmpty(name) && item.Name == name))
                    return item;
            }
            return null;
        }
        private void RemoveOnline(TcpChannel e)
        {
            lock (mLockOnlineChange)
            {
                Clients.Remove(e);
            }
        }
        protected void OnConnected(TcpChannel e)
        {
            AddOnline(e);
            e.Server = this;
            e.ChannelDisposed += OnClientDisposed;
            if (ChannelConnected != null)
                ChannelConnected(this, new ChannelEventArgs() { Channel = e });
        }
        protected void OnClientDisposed(object source, ChannelEventArgs e)
        {
            e.Channel.Server = null;
            RemoveOnline(e.Channel);
            if (ChannelDisposed != null)
                ChannelDisposed(this, e);
        }
        public void Open(IPEndPoint ipendpoint)
        {
            
            Open(ipendpoint, 100);
        }
        public void Open(IPEndPoint ipendpoint, int listens)
        {
            mPoint = ipendpoint;
            if (mSocket != null)
            {
                Dispose();
            }
            mSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            Socket.Bind(ipendpoint);
            Socket.Listen(listens);
            System.Threading.ThreadPool.QueueUserWorkItem(BeginAccept, Socket);

        }
        private void BeginAccept(object data)
        {
          
          
            while (IsRun && Socket !=null)
            {

                try
                {
                    allDone.Reset();
                    Socket.BeginAccept(new AsyncCallback(AcceptCallback), Socket);
                    allDone.WaitOne();
                }
                catch (SocketException serr)
                {
                    Core.Log.WriteFormat<TcpServer>(Core.Log.LogType.Error, "{0}Tcp服务错误终止!Error:{1}\tErrorCode:{2}", mPoint, serr.Message, serr.ErrorCode);
                    try
                    {
                        mSocket.Close();
                        mSocket = null;
                    }
                    catch
                    {
                    }
                }
                catch (Exception e_)
                { 
                }
            }
        }
        public void Open(string ip, int port)
        {
            Open(ip, port, 100);
        }
        public void Open(string ip, int port, int listens)
        {
            Open(new IPEndPoint(IPAddress.Parse(ip), port), listens);
        }

        public void AcceptCallback(IAsyncResult ar)
        {
            TcpChannel client =null;
			try
			{
				
				Socket listener = (Socket)ar.AsyncState;
            	Socket handler = listener.EndAccept(ar);
                allDone.Set();
                bool create = true;
                foreach(KeyValuePair<Type,IIPFiler> item in mFilters)
                {
                    create = item.Value.Execute((IPEndPoint)handler.RemoteEndPoint);
                    if (!create)
                        break;


                }
                if (create)
                {
                    client = new TcpChannel(handler);
                    OnConnected(client);
                }
                else
                {
                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();
                }
				
			}
			catch(SocketException e_)
			{
                Core.Log.WriteFormat<TcpServer>(Core.Log.LogType.Error, "{0}Tcp服务错误终止!Error:{1}\tErrorCode:{2}", mPoint, e_.Message, e_.ErrorCode);
                try
                {
                    mSocket.Close();
                    mSocket = null;
                }
                catch
                {
                }
			}
            catch(Exception e__)
			{
				if(client !=null)
					client.CallChannelError(new ChannelErrorEventArgs{ Channel=client, Exception=e__});
			}
			
        }
        #endregion

        public static TcpChannel CreateClient(string ip, int port)
        {
            return CreateClient(new IPEndPoint(IPAddress.Parse(ip), port));
        }
        public static TcpChannel CreateClient(IPEndPoint endpoint)
        {
            Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            clientSocket.Connect(endpoint);
            TcpChannel client = new TcpChannel(clientSocket);
            client.Name = client.Socket.RemoteEndPoint.ToString();
            return client;
        }
        #region IDisposable 成员

        public void Dispose()
        {
            lock (this)
            {
                if (IsRun)
                {
                    IsRun = false;
                    mClients.Clear();
                    allDone.Set();
                    if (Socket != null)
                        Socket.Close();
                }
            }
        }

        #endregion
    }
}

