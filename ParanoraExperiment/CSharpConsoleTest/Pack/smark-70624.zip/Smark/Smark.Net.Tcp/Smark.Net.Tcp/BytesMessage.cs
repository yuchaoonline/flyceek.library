﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class BytesMessage:IMessage
    {
        public byte[] Value
        {
            get;
            set;
        }
        private int mLength;
        public void Save(Encoding Coding, DataBuffer writer)
        {
            writer.Write(Value);
            mLength = writer.Count;

        }

        public void Load(Encoding Coding, DataBuffer reader)
        {
            Value= reader.GetBytes();
            mLength = reader.Count;

        }

        public int Length
        {
            get { return mLength ; }
        }
    }
}
