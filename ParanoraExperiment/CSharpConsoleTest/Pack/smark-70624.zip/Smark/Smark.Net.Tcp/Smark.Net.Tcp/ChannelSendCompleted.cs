﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class ChannelSendCompletedArgs : ChannelEventArgs
    {
        public IMessage Message
        {
            get;
            internal set;
        }
    }
}
