﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Threading;
namespace Smark.Net.Tcp
{
    public class TcpSocketAsyncEventArgs:SocketAsyncEventArgs
    {
        public TcpSocketAsyncEventArgs(int length)
        {
            Byte[] data = new byte[length];
            SetBuffer(data, 0, data.Length);
        }


        public TcpSocketAsyncEventArgsPool Pool
        {
            get;
            set;
        }
        public TcpChannel Channel
        {
            internal get;
            set;
        }
        public void Reset()
        {
            SetBuffer(0, Buffer.Length);
        }
        public void Enter()
        {
            Channel = null;
            if (Pool != null)
                Pool.Push(this);
        }
        protected override void OnCompleted(SocketAsyncEventArgs e)
        {
            base.OnCompleted(e);
            if (e.LastOperation == SocketAsyncOperation.Send)
            {
                IO_SendComplete((TcpSocketAsyncEventArgs)e);
            }
            else if (e.LastOperation == SocketAsyncOperation.Receive)
            {
                IO_ReceiveComplete((TcpSocketAsyncEventArgs)e);
            }
            else{
                if (e.SocketError != System.Net.Sockets.SocketError.Success)
                {
                    Channel.Dispose();
                }
            }
        }

        public void IO_ReceiveComplete(TcpSocketAsyncEventArgs e)
        {
            TcpChannel channel = e.Channel;
            if (e.BytesTransferred > 0 && e.SocketError == System.Net.Sockets.SocketError.Success)
            {
                ReceiveWorkItem item = new ReceiveWorkItem();
                item.SocketAsyncEventArgs = e;
                item.Channel = e.Channel;
                channel.ReceiveDespatch.Add(item);
                channel.BeginReceive();
                
            }
            else
            {
                
                e.Enter();
                channel.Dispose();

            }
        }
        public void IO_SendComplete(TcpSocketAsyncEventArgs e)
        {
            SendQueue sq = e.Channel.SendQueue;
            TcpChannel channel = e.Channel;
            SendUserToken state = (SendUserToken)e.UserToken;
            state.SendBytes += e.BytesTransferred;
         
            if (e.SocketError == System.Net.Sockets.SocketError.Success && e.BytesTransferred > 0)
            {
                if (state.TotalBytes == state.SendBytes)
                {
                    ChannelSendCompletedArgs csc = new ChannelSendCompletedArgs();
                    csc.Message = state.Message;
                    csc.Channel = channel;
                    channel.OnSendCompleted(csc);
                    
                   
                    sq.Reset();
                    sq.Send(e);
                }
                else
                {
                    channel.SendDataBuffer(state, e);

                }
            }
            else
            {
                
                channel.Dispose();
            }
        }

    }
}
