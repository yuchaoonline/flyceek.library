﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class PacketAnalysis<T> : IDisposable where T : IPacketEof, new()
    {
        
        public PacketAnalysis(Tcp.TcpChannel channel)
        {
            mChannel = channel;

            mBufferPool = TcpUtils.GetDataBufferPool(); //Utils.GetSendDataBufferPool();
            mData = mBufferPool.Pop();
            mPacketEofHandler.Coding = channel.Coding;
        }
        private Tcp.TcpChannel mChannel;
        public Tcp.TcpChannel Channel
        {
            get
            {
                return mChannel;
            }
        }
        public Encoding Coding
        {
            get
            {
                return mChannel.Coding;
            }
        }
        public event EventPacketDataReader Receive;

        public DataBufferPool mBufferPool;
        private DataBuffer mData;
        private T mPacketEofHandler = new T();
        public void Import(DataBuffer db)
        {

            byte[] eofdata = mPacketEofHandler.EofData;
            for (int i = 0; i < db.Count; i++)
            {
                mData.Write(db.Data[i]);
                if (mPacketEofHandler.Eof(mData, db, eofdata))
                {
                   
                    ExecuteReceive(mData);
                 
                    mData = mBufferPool.Pop();

                }

            }
        }

        protected virtual void ExecuteReceive(DataBuffer dr)
        {
            using (dr)
            {
                try
                {
                    
                    OnReceive(dr);
                }
                catch (Exception e_)
                {
                    Channel.CallChannelError(new ChannelErrorEventArgs() { Exception = e_, Channel = Channel });
                }
            }
        }
        protected void OnReceive(DataBuffer dr)
        {
            PacketDataReaderArgs e = new PacketDataReaderArgs(Channel, dr);
            if (Receive != null)
                Receive(e);
        }

        #region IDisposable 成员

        public void Dispose()
        {
            if (mData != null)
                mData.Dispose();
        }

        #endregion
    }
}
