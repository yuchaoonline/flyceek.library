﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public class DefaultIPFilter:IIPFiler
    {
        private List<IpItem> mItems = new List<IpItem>();
        public void Add(IpItem item)
        {
            mItems.Add(item);
        }
        public bool Execute(System.Net.IPEndPoint point)
        {
            bool result = false;
            foreach (IpItem item in mItems)
            {
                result = item.Equals(point);
                if (!result)
                    break;
            }
            return result;
        }
    }
}
