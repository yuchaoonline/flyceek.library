﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Smark.Net.Tcp
{
    public delegate void EventPacketDataReader(PacketDataReaderArgs e);
    public class PacketDataReaderArgs
    {
        public PacketDataReaderArgs(TcpChannel channel, DataBuffer buffer)
        {
            mChannel = channel;
            mBuffer = buffer;
        }
        private TcpChannel mChannel;
        private DataBuffer mBuffer;
        public TcpChannel Channel
        {
            get
            {
                return mChannel;
            }
        }
        public DataBuffer Buffer
        {
            get
            {
                return mBuffer;
            }
        }
    }
}
